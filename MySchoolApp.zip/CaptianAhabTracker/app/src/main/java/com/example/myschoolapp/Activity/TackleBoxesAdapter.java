package com.example.myschoolapp.Activity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.TackleBox;


import java.util.List;

public class TackleBoxesAdapter extends RecyclerView.Adapter<TackleBoxesAdapter.TackleBoxViewHolder> {
    /***
     ** - 3. create the list of cours up top
     */
    private List<TackleBox> mTackleBoxes;

    /***
     ** - declaring the context
     */
    private final Context context;

    /***
     ** - declaring the inflater
     */
    private final LayoutInflater mInflater;

    public TackleBoxesAdapter(Context context) {
       mInflater = LayoutInflater.from(context);
       this.context= context;
    }


    public class TackleBoxViewHolder extends RecyclerView.ViewHolder {
        /***
         ** - item layout only has 1 text view
         */
        private final TextView tackleBoxItemListView;
        private final TextView associatedTackleItemView;




        public TackleBoxViewHolder(@NonNull View itemView) {
            super(itemView);
            tackleBoxItemListView = itemView.findViewById(R.id.textViewTackleBoxItemList);
            associatedTackleItemView = itemView.findViewById(R.id.associatedTackleItemView);



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int tacklePosition = getAdapterPosition();
                    final TackleBox currentTackleBox = mTackleBoxes.get(tacklePosition); // need a method to get the current tackleBox on the list

                    // need to go to the tackleBox detail page
                    Intent goToTackleBoxDetailPageBridge = new Intent(context, TackleBoxDetailPage.class);

                    /***
                     ** - 7. need to use the putExtra method
                     ** - we need tackleBox id, tackleBox name, tackleBox start and end dates
                     ** - tackleBox instructors name, email, phone number
                     ** - tackleBox notes and tackleBox status
                     ** - rodAndReel id
                     ** - need to go to the next screen or start the activity after
                     */
                    //id - this won't populate on the screen
                    goToTackleBoxDetailPageBridge.putExtra("id", currentTackleBox.getTackleBoxID());

                    // name
                    goToTackleBoxDetailPageBridge.putExtra("name", currentTackleBox.getTackleBoxName());


                    // begin date -  this will change because of the date picker
                    goToTackleBoxDetailPageBridge.putExtra("beginDate", currentTackleBox.getTackleBoxStartDay());


                    // end date - changing due to date picker
                    goToTackleBoxDetailPageBridge.putExtra("endDate", currentTackleBox.getTackleBoxEndDay());


                    // tackleBox instructor name
                    goToTackleBoxDetailPageBridge.putExtra("courseInstructorName", currentTackleBox.getManufacturerName());
                    // tackleBox instructors email
                    goToTackleBoxDetailPageBridge.putExtra("courseInstructorEmail", currentTackleBox.getManEmailAddress());
                    // tackleBox instructors phone
                    goToTackleBoxDetailPageBridge.putExtra("courseInstructorPhoneNumber", currentTackleBox.getManPhoneNumber());


                    // tackleBox notes -  changing to share
                    goToTackleBoxDetailPageBridge.putExtra("courseNotes", currentTackleBox.getNotes());
                    // tackleBox status - changing with a dropdown/spinner
                    goToTackleBoxDetailPageBridge.putExtra("courseStatus", currentTackleBox.getStatus());


                    // rodAndReel id
                    goToTackleBoxDetailPageBridge.putExtra("termID", currentTackleBox.getRodAndReelID());
                    // going to other screen activity
                    context.startActivity(goToTackleBoxDetailPageBridge);


                }
            });

        }
    }




    /***
     ** - 6. onCreateViewHolder
     ** - need to inflate
     */
    @NonNull
    @Override
    public TackleBoxViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.tackle_boxes_item_layout,
                parent, false);



        // need to return the viewHolder
        return new TackleBoxViewHolder(itemView);

    }




    /***
     ** 8. - this is where we will display where we want to put it on the recylcer view
     ** - can't be null, using if
     */

    @Override
    public void onBindViewHolder(@NonNull TackleBoxViewHolder holder, int position) {


        if(mTackleBoxes != null){
            TackleBox currentTackleBoxForBindView = mTackleBoxes.get(position);
            String nameToFind = currentTackleBoxForBindView.getTackleBoxName();
            holder.tackleBoxItemListView.setText(nameToFind);
        }
        else{
            holder.tackleBoxItemListView.setText("No TackleBox Found");


        }

    }






    /***
     ** 4. - getItem method
     **  - need to change return from 0 to mTackleboxes
     */
    @Override
    public int getItemCount() {
        if (mTackleBoxes != null) {
            return mTackleBoxes.size();
        } else
            return 0;
    }


    /***
     ** 2. - method for setting the list
     */

    public void setTackleBoxes(List<TackleBox> tackleBoxes) {
        mTackleBoxes = tackleBoxes;
        notifyDataSetChanged();
    }

    /***
     ** 5. - method for the inflator
     */



}
