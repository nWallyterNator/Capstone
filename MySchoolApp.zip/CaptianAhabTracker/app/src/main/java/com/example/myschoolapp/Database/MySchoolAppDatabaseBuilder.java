package com.example.myschoolapp.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.myschoolapp.DAO.BaitDAO;
import com.example.myschoolapp.DAO.TackleBoxDAO;
import com.example.myschoolapp.DAO.RodAndReelDAO;
import com.example.myschoolapp.entities.Bait;
import com.example.myschoolapp.entities.TackleBox;
import com.example.myschoolapp.entities.RodAndReel;

/****
 *** @author Nicholas Walters
 **/
@Database(entities = {RodAndReel.class, TackleBox.class, Bait.class}, version = 34, exportSchema = false)

public abstract class MySchoolAppDatabaseBuilder extends RoomDatabase {


    public abstract TackleBoxDAO tackleBoxDAO();

    public abstract RodAndReelDAO rodAndReelDAO();

    public abstract BaitDAO baitDAO();

    private static volatile MySchoolAppDatabaseBuilder INSTANCE;

    static MySchoolAppDatabaseBuilder getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (MySchoolAppDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), MySchoolAppDatabaseBuilder.
                                    class, "MyDatabase.db")
                            .fallbackToDestructiveMigration()
                            .build();


                }
            }
        }
        return INSTANCE;

    }


/****
 *** end of the line
 *** don't continue
 **/
}
