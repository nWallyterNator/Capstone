package com.example.myschoolapp.Activity.Polymorphism;

/****
 *** @author Nicholas Walters
 **/
import androidx.room.Entity;

import com.example.myschoolapp.entities.Bait;

@Entity(tableName = "artificial bait")
public class ArtificialBait extends Bait {

  private int artificialBaitReference;

    public ArtificialBait(int baitID, String baitName, String beginBaitDay, String endBaitDay, String typeOfBait, int tackleBoxID, int artificialBaitReference) {
        super(baitID, baitName, beginBaitDay, endBaitDay, typeOfBait, tackleBoxID);
        this.artificialBaitReference = artificialBaitReference;
    }

    public int getArtificialBaitReference() {
        return artificialBaitReference;
    }

    public void setArtificialBaitReference(int artificialBaitReference) {
        this.artificialBaitReference = artificialBaitReference;
    }
}
