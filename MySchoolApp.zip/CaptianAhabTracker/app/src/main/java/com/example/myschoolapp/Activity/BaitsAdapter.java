package com.example.myschoolapp.Activity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Bait;

import java.util.List;

public class BaitsAdapter extends RecyclerView.Adapter<BaitsAdapter.AssessmentsViewholder> {
    /***
     ** - 3. create the list of rodAndReels up top
     */
    private List<Bait> mBaits;


    /***
     ** - declaring the context
     */
    private final Context context;

    /***
     ** - declaring the inflater
     */
    private final LayoutInflater mInflater;

    public class AssessmentsViewholder extends RecyclerView.ViewHolder {
        /***
         ** - baits_item layout only has 1 text view
         */
        private final TextView baitItemListView;
       private final TextView baitItemView;


        public AssessmentsViewholder(@NonNull View itemView) {
            super(itemView);
            baitItemListView = itemView.findViewById(R.id.baitsItemView);
         baitItemView = itemView.findViewById(R.id.baitItemViewForTackleBoxDetails);


            baitItemListView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int baitPosition = getAdapterPosition();
                    final Bait currentBait = mBaits.get(baitPosition);// creating a method to get it

                    // need to go to the assessment detail page
                    Intent goToBaitDetailPageBridge = new Intent(context, BaitDetailPage.class);

                    /***
                     ** - 7. need to use the putExtra method
                     ** - we need bait id, tes name, rodAndReel start and end dates
                     ** - need type of bait whether its artificial or live
                     ** - tackleBox id
                     ** - need to go to the next screen or start the activity after
                     */
                    // test id
                    goToBaitDetailPageBridge.putExtra("assessmentID", currentBait.getBaitID());
                    // test name
                    goToBaitDetailPageBridge.putExtra("assessmentName", currentBait.getBaitName());


                    // begin date - changing due to date picker
                    goToBaitDetailPageBridge.putExtra("beginDate", currentBait.getBeginBaitDay());
                    // end date - changing due to dae picker
                    goToBaitDetailPageBridge.putExtra("endDate", currentBait.getEndBaitDay());


                    // type of test - changing because plan on using radio button
                    goToBaitDetailPageBridge.putExtra("testType", currentBait.getTypeOfBait());


                    // need tackleBox id
                    goToBaitDetailPageBridge.putExtra("courseID", currentBait.getTackleBoxID());
                    // going to the next activity
                    context.startActivity(goToBaitDetailPageBridge);


                }
            });


        }
    }


    /***
     ** - 6. onCreateViewHolder
     ** - need to inflate
     */
    @NonNull
    @Override
    public BaitsAdapter.AssessmentsViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = mInflater.inflate(R.layout.baits_item_layout,
                parent, false);


        // need to return the viewHolder
        return new AssessmentsViewholder(itemView);

    }




    /***
     ** 8. - this is where we will display where we want to put it on the recylcer view
     ** - can't be null, using if
     */
    @Override
    public void onBindViewHolder(@NonNull BaitsAdapter.AssessmentsViewholder holder, int position) {




        if(mBaits != null){
            Bait currentBaitForBindView = mBaits.get(position);
            String nameToFind = currentBaitForBindView.getBaitName();
            holder.baitItemListView.setText(nameToFind);
        }
        else{
            holder.baitItemListView.setText("No Bait Found");
        }

    }


    /***
     ** 4. - getItem method
     **  - need to change return from 0 to mBaits
     */
    @Override
    public int getItemCount() {
        if (mBaits != null) {
            return mBaits.size();
        } else
            return 0;
    }


    /***
     ** 2. - method for setting the list
     */

    public void setBaits(List<Bait> baits) {
        mBaits = baits;
        notifyDataSetChanged();
    }

    /***
     ** 5. - method for the inflator
     */
    public BaitsAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context = context;


    }

}
