package com.example.myschoolapp.Activity.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myschoolapp.Activity.MainActivity;
import com.example.myschoolapp.R;

/****
 *** @author Nicholas Walters
 **/

public class Login extends AppCompatActivity {
    // need to declare for the username, password, button and text

    // Edit texts
    EditText userNameForLoginPage, inputPasswordConfirmationForLoginPage;

    // Button
    Button registerBtnForLogin;

    // textView
    TextView newUserSignInForLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // ids

        // username
        userNameForLoginPage = findViewById(R.id.userNameForLoginPage);

        //password
        inputPasswordConfirmationForLoginPage = findViewById(R.id.inputPasswordConfirmationForLoginPage);

        // sign in button
        registerBtnForLogin = findViewById(R.id.registerBtnForLogin);


        // functionality for the register/sign in btn
        registerBtnForLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                // calling method to check that they are equal
                checkToMakeSureItIsSame(userNameForLoginPage.getText().toString(), inputPasswordConfirmationForLoginPage.getText().toString());

            }


        });


    }



    /*(****)---(****)---     METHODS    (****)--- (****)--- (****)--- (****)---

            (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)---  */


    private void checkToMakeSureItIsSame(String username, String password) {

        // making sure fish is keyed in for both fields
        if (username.equals("fish") && password.equals("fish")) {

            Intent goToMainScreen = new Intent(Login.this, MainActivity.class);
            startActivity(goToMainScreen);

        } else {

            Toast.makeText(getApplicationContext(), "Invalid username or password. Type fish for both fields", Toast.LENGTH_LONG).show();
        }


    }

}


