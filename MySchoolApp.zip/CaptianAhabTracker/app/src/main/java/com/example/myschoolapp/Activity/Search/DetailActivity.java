package com.example.myschoolapp.Activity.Search;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myschoolapp.Activity.MainActivity;
import com.example.myschoolapp.R;
/****
 *** @author Nicholas Walters
 **/
public class DetailActivity extends AppCompatActivity {

    // creating the selected stuff
    Stuff selectedStuff;

    /***
     ** - 1. 2 main goals
     ** - get our thing
     ** - set values
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // getting our thing method
        getSelectedStuff();

        // setting the values of the thing
        setValues();

    }






      /*$%^^%$$%^^%$ $%^^%$    METHODS    $%^^%$ $%^^%$ $%^^%$ $%^^%$

    $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ */

    private void getSelectedStuff() {

        Intent previousIntent = getIntent();

        String parsedStringID = previousIntent.getStringExtra("id");

        selectedStuff = StuffMainActivity.stuffList.get(Integer.valueOf(parsedStringID));


    }


    private void setValues() {

        TextView textView = (TextView) findViewById(R.id.stuffName);

        ImageView imageView = (ImageView) findViewById(R.id.stuffImage);


        textView.setText(selectedStuff.getName());

        imageView.setImageResource(selectedStuff.getImage());


    }

    /***
     ** 3. - functionality with the menu button
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_stuff_cell, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem menuItem) {
        // going to test details screen to add a test
        if (menuItem.getItemId() == R.id.purchaseItem) {
            Intent goToPurchasePage = new Intent(DetailActivity.this, ConfirmationScreen.class);

            Toast.makeText(DetailActivity.this,
                    // test to make sure it go to the page
                    "Purchasing....",
                    Toast.LENGTH_SHORT).show();
            startActivity(goToPurchasePage);
        }

        if (menuItem.getItemId() == R.id.homePage) {
            Intent goBackToHomePage = new Intent(DetailActivity.this, MainActivity.class);

            Toast.makeText(DetailActivity.this,
                    // test to make sure it go to the page
                    "Going Back To the Home Page",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToHomePage);

            return true;
        }
        return true;


        /****
         *** end of the line
         *** don't continue
         **/
    }
}