package com.example.myschoolapp.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.myschoolapp.entities.RodAndReel;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/

@Dao
public interface RodAndReelDAO {

    /***
     ** 1. - update, insert, delete, get all Terms
     */

    // update
    @Update
    void updateRodAndReel(RodAndReel rodAndReel);

    //delete
    @Delete
    void deleteRodAndReel(RodAndReel rodAndReel);

    // insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertRodAndReel(RodAndReel rodAndReel);

    //get all terms
@Query("SELECT * FROM rods ORDER BY rodAndReelID ASC")
    List<RodAndReel> getAllRodsAndReels();



}
