package com.example.myschoolapp.Activity.Search;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myschoolapp.Activity.MainActivity;
import com.example.myschoolapp.R;

import java.util.ArrayList;

/****
 *** @author Nicholas Walters
 **/
public class StuffMainActivity extends AppCompatActivity {
    /***
     ** - 1. Three Main Goals
     ** - set up data
     ** - set up the list
     ** - set up onclick listener
     */

    /***
     ** - 2. creating a new Method for the search bar
     */

    // making an array list
    public static ArrayList<Stuff> stuffList = new ArrayList<Stuff>();

    // ListView
    private ListView listView;

    // declaring a string for all
    private String selectedFilter = "all";

    // finding a current search text
    private  String currentSearchText = "";

    // searchView
    private SearchView searchView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stuff_main);

        // set up data
        setupData();

        // set up list
        setupList();

        //set up onclick listener
        setUpOnclickListener();


        // new method for searching with search bar
        searchBarMethod();


    }








      /*$%^^%$$%^^%$ $%^^%$    METHODS    $%^^%$ $%^^%$ $%^^%$ $%^^%$

    $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ */

    private void setupData() {

        // rod reel, tackle, bait

        Stuff rod = new Stuff("0", "Orvis Fly Rod Reel ", R.drawable.rod_reels);
        stuffList.add(rod);

        Stuff tackle = new Stuff("1", "Johnsons TackleBox ", R.drawable.tackle);
        stuffList.add(tackle);


        Stuff bait = new Stuff("2","Freddys NightCrawlers Bait", R.drawable.worm);
        stuffList.add(bait);


        Stuff rod1 = new Stuff("3", "Sage Rod Reel Combo", R.drawable.rod_reels);
        stuffList.add(rod1);

        Stuff tackle1 = new Stuff("4", "Old Mans TackleBox ", R.drawable.tacklebox);
        stuffList.add(tackle1);


        Stuff bait1 = new Stuff("5","Jakes Spinner Bait", R.drawable.spinner);
        stuffList.add(bait1);



        Stuff rod2 = new Stuff("6", "Reddington Rod and Reel ", R.drawable.rod_reels);
        stuffList.add(rod2);

        Stuff tackle2 = new Stuff("7", "Cabellas Tackle", R.drawable.tackle1);
        stuffList.add(tackle2);


        Stuff bait2 = new Stuff("8","Smelly Shrimp Bait", R.drawable.shrimp);
        stuffList.add(bait2);




    }

    private void setupList() {
        listView = (ListView) findViewById(R.id.thingsListView);

        StuffAdapter adapter = new StuffAdapter(getApplicationContext(),0,stuffList);

        listView.setAdapter(adapter);
    }

    private void setUpOnclickListener(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                Stuff selectedStuff = (Stuff) (listView.getItemAtPosition(position));

                Intent showDetail = new Intent(getApplicationContext(),DetailActivity.class);

                showDetail.putExtra("id",selectedStuff.getId());

                startActivity(showDetail);


            }
        });
    }

    /****
     * - fix for the cancel duplicating the things
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_stuff_main, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.cancelGoBackHome) {
            Intent goBackToHomePageFromLowStock = new Intent(StuffMainActivity.this, MainActivity.class);


            Toast.makeText(StuffMainActivity.this,
                    // test to make sure it go to the page
                    "Canceling Request",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToHomePageFromLowStock);
        }
        return true;
    }

    private void searchBarMethod() {

        searchView = (SearchView) findViewById(R.id.thingsListViewSearchView);

        // setting it to on query text listener
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                currentSearchText =s;
                ArrayList<Stuff> filteredStuff = new ArrayList<Stuff>();

                // for loop
                for(Stuff stuff : stuffList){
                    if(stuff.getName().toLowerCase().contains(s.toLowerCase())){
                        if(selectedFilter.equals("all")) {
                            filteredStuff.add(stuff);
                        }
                        else{
                            if(stuff.getName().toLowerCase().contains(selectedFilter)){
                                filteredStuff.add(stuff);
                            }
                        }
                    }
                }
                StuffAdapter adapter = new StuffAdapter(getApplicationContext(),0,filteredStuff);

               listView.setAdapter(adapter);

                return false;
            }
        });


    }


    // making a filtered list method
    private void filterList(String status){

        selectedFilter = status;
        ArrayList<Stuff> filteredStuff = new ArrayList<>();

        for(Stuff stuff : stuffList){
            if(stuff.getName().toLowerCase().contains(status)){

                if(currentSearchText ==""){
                    filteredStuff.add(stuff);
                }

                else{
                    if(stuff.getName().toLowerCase().contains(currentSearchText.toLowerCase())){
                        filteredStuff.add(stuff);
                    }
                }


            }
        }
        StuffAdapter adapter = new StuffAdapter(getApplicationContext(),0,filteredStuff);

        listView.setAdapter(adapter);

    }

    public void allFilterTapped(View view) {

        selectedFilter = "all";
        searchView.setQuery("",false);

        searchView.clearFocus();

        StuffAdapter adapter = new StuffAdapter(getApplicationContext(),0,stuffList);

        listView.setAdapter(adapter);
    }

    public void rodReelFilterTapped(View view) {

        filterList("reel");
    }

    public void baitFilterTapped(View view) {
        filterList("bait");
    }

    public void tackleFilterTapped(View view) {
        filterList("tackle");
    }


/****
 *** end of the line
 *** don't continue
 **/
}