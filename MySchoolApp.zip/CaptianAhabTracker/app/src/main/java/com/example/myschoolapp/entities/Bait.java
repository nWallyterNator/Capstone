package com.example.myschoolapp.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/****
 *** @author Nicholas Walters
 **/

@Entity(tableName = "bait")
public class Bait {
    /***
     ** 1. - need to get bait name
     **    - begin and end days
     **    - type of bait
     **    -  id(pk) for bait
     **    -  id(fk) for bait
     */
    @PrimaryKey(autoGenerate = true)
    private int baitID;

    private String baitName;

    private String beginBaitDay, endBaitDay;

    private String typeOfBait;

    private int tackleBoxID;

    /***
     ** 1. - need to get constructor
     */
    public Bait(int baitID, String baitName, String beginBaitDay, String endBaitDay, String typeOfBait, int tackleBoxID) {
        this.baitID = baitID;
        this.baitName = baitName;
        this.beginBaitDay = beginBaitDay;
        this.endBaitDay = endBaitDay;
        this.typeOfBait = typeOfBait;
        this.tackleBoxID = tackleBoxID;
    }

    /***
     ** 2. - getters and setters
     */
    public int getBaitID() {
        return baitID;
    }

    public void setBaitID(int baitID) {
        this.baitID = baitID;
    }

    public String getBaitName() {
        return baitName;
    }

    public void setBaitName(String baitName) {
        this.baitName = baitName;
    }

    public String getBeginBaitDay() {
        return beginBaitDay;
    }

    public void setBeginBaitDay(String beginBaitDay) {
        this.beginBaitDay = beginBaitDay;
    }

    public String getEndBaitDay() {
        return endBaitDay;
    }

    public void setEndBaitDay(String endBaitDay) {
        this.endBaitDay = endBaitDay;
    }

    public String getTypeOfBait() {
        return typeOfBait;
    }

    public void setTypeOfBait(String typeOfBait) {
        this.typeOfBait = typeOfBait;
    }

    public int getTackleBoxID() {
        return tackleBoxID;
    }

    public void setTackleBoxID(int tackleBoxID) {
        this.tackleBoxID = tackleBoxID;
    }

    public String toString() {
        return baitID + " " + baitName;
    }

    /****
     *** end of the line
     *** don't continue
     **/
}
