package com.example.myschoolapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.RodAndReel;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/

public class RodAndReels extends AppCompatActivity {

    // have 2 buttons

    /***
     ** 1. button needs to go to the RodAndReels details page
     */

    Button addRodAndReelBtn, cancelBtn;
    private Repository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rod_and_reels);

        addRodAndReelBtn = findViewById(R.id.goToRodDetails);
        // adding functionality to the button to move to the next activity the rod/reel detail page
        addRodAndReelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToRodAndReelsDetailPage = new Intent(RodAndReels.this, RodAndReelDetailPage.class);

                Toast.makeText(RodAndReels.this,
                        // test to make sure it go to the page
                        "Going to Rod and Reel Detail Page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToRodAndReelsDetailPage);
            }
        });


        /***
         ** - home button needs to go to the home page
         ** - need to make sure that the go back button also gets rid of things
         */
        cancelBtn = findViewById(R.id.button);


        cancelBtn = findViewById(R.id.button);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBackFromRodAndReelsListPage = new Intent(RodAndReels.this, MainActivity.class);
                {
                    Toast.makeText(RodAndReels.this,
                            // test to make sure it go to the page
                            "Canceling Request",
                            Toast.LENGTH_SHORT).show();
                    startActivity(goBackFromRodAndReelsListPage);
                }
            }
        });

        /***
         ** 2. need to create the recycler view and populate it
         ** - will query the database or put something on it
         ** - adding with the getAll
         ** - need to call the rod adapter
         ** -  set the adapter on the recylcer view
         ** - layout manager needs to be set to recyclerView
         ** - need to do Adapter.set() to put the list on the recycler view
         */
        RecyclerView rodsRecyclerView = findViewById(R.id.recyclerView);

        // querying the database
        repository = new Repository(getApplication());

        //  need to get it from the repository and put it on the list
        List<RodAndReel> allAvailableRodAndReels = repository.getmAllRodsAndReels();

        // termAdapter
        final RodAndReelsAdapter rodAndReelsAdapter = new RodAndReelsAdapter(this);

        // setting on the recyclerView
        rodsRecyclerView.setAdapter(rodAndReelsAdapter);

        // layout view to recycler view
        rodsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // adapter.set method
        rodAndReelsAdapter.setRodAndReels(allAvailableRodAndReels);


    }

    /***
     ** 3. - functionality with the menu button
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_rods_reels, menu);
        return true;
    }

    /***
     ** 4. - this will take it to the tackle list page
     */
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        // going to tackleBox details screen to add a tackleBox
        if (menuItem.getItemId() == R.id.tackleMenuPage) {
            Intent goToTackleScreen = new Intent(RodAndReels.this, TackleBoxes.class);

            Toast.makeText(RodAndReels.this,
                    // test to make sure it go to the page
                    "Adding Tackle",
                    Toast.LENGTH_SHORT).show();
            startActivity(goToTackleScreen);
        }


        /****
         *** end of the line
         *** don't continue
         **/

    /*@!@!@!@!@!@!@   REQUIREMENTS    @!@!@!@!@!@!@@!@!@!@!@!@!@
    - need to be able add as many rods as I can
    - rod/reels needs title, order date, sold date and I will add id
    - rod/reels can't be deleted with tackle with it
    - this needs to go to rod/reel details
    - need to make it so it can go back and fourth
    - rod/reel details needs to go to tackle list



    @!@!@!@!@!@!@@!@!@!@!@!@!@@!@!@!@!@!@!@@!@!@!@!@!@!@@!@!@!@!@!@!@
  */
        return true;
    }


}