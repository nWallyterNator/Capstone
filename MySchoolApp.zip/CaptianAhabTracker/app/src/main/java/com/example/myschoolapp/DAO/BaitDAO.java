package com.example.myschoolapp.DAO;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.myschoolapp.entities.Bait;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/

@Dao
public interface BaitDAO {


    /***
     ** 1. - update, insert, delete, get all tests
     */

    //delete
    @Delete
    void deleteBait(Bait bait);

    //update
    @Update
    void updateBait(Bait bait);

    //insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertBait(Bait bait);

    // get all baits
    @Query("SELECT * FROM bait ORDER BY baitID")
    List<Bait> getAllBait();


}
