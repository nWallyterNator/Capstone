package com.example.myschoolapp.Activity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.RodAndReel;

import java.util.List;

public class RodAndReelsAdapter extends RecyclerView.Adapter<RodAndReelsAdapter.RodAndReelsViewHolder> {
    /***
     ** - 3. create the list of rodAndReels up top
     */
    private List<RodAndReel> mRodAndReels;

    /***
     ** - declaring the context
     */
    private final Context context;

    /***
     ** - declaring the inflater
     */
    private final LayoutInflater mInflater;


    /***
     ** 1. - ViewHolder
     */
    public class RodAndReelsViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewRodAndReelItemList;

        /***
         ** - initialize it in the constructor
         */
        public RodAndReelsViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewRodAndReelItemList = itemView.findViewById(R.id.textViewRodAndReelItemList);
            textViewRodAndReelItemList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int rodAndReelPosition = getAdapterPosition();
                    final RodAndReel currentRodAndReel = mRodAndReels.get(rodAndReelPosition); // adding a method get the item from the list

                    // need to go to the screen
                    Intent goToRodAndReelDetailPageBridge = new Intent(context, RodAndReelDetailPage.class);


                    /***
                     ** - 7. need to use the putExtra method
                     ** - we need rodAndReel id, rodAndReel name, rodAndReel start and end dates
                     ** - need to go to the next screen or start the activity after
                     */

                    //id
                    goToRodAndReelDetailPageBridge.putExtra("id", currentRodAndReel.getRodAndReelID());
                    //name
                    goToRodAndReelDetailPageBridge.putExtra("name", currentRodAndReel.getRodAndReelName());


                    // begin date - this will change with date picker
                    goToRodAndReelDetailPageBridge.putExtra("startingDate", currentRodAndReel.getStartRodAndReelDay());

                    // end date -  this will change with date picker
                    goToRodAndReelDetailPageBridge.putExtra("endingDate", currentRodAndReel.getEndRodAndReelDay());


                    /************
                     ***********
                     */
                    goToRodAndReelDetailPageBridge.putExtra("created", currentRodAndReel.getCreatedDateForReport());





                    // going to next activity
                    context.startActivity(goToRodAndReelDetailPageBridge);







                }
            });


        }
    }




    /***
     ** - 6. onCreateViewHolder
     ** - need to inflate
     */
    @NonNull
    @Override
    public RodAndReelsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.rod_and_reels__item_layout,
                parent, false);



        // need to return the viewHolder
        return  new RodAndReelsViewHolder(itemView);



    }


    /***
     ** 8. - this is where we will display where we want to put it on the recylcer view
     ** - can't be null, using if
     */
    @Override
    public void onBindViewHolder(@NonNull RodAndReelsViewHolder holder, int position) {

        if(mRodAndReels != null){
            RodAndReel currentRodAndReelForBindView = mRodAndReels.get(position);
            String nameToFind = currentRodAndReelForBindView.getRodAndReelName();
            holder.textViewRodAndReelItemList.setText(nameToFind);
        }
        else{
            holder.textViewRodAndReelItemList.setText("No RodAndReel Found");
        }





    }








    /***
     ** 4. - getItem method
     **  - need to change return from 0 to mRodAndReels
     **   -  making it an if else statement so that it won't crash
     */
    @Override
    public int getItemCount() {
        if (mRodAndReels != null) {
            return mRodAndReels.size();
        } else
            return 0;
    }


    /***
     ** 2. - method for setting the list
     */

    public void setRodAndReels(List<RodAndReel> rodAndReels) {
        mRodAndReels = rodAndReels;
        notifyDataSetChanged();
    }


    /***
     ** 5. - method for the inflator
     */
    public RodAndReelsAdapter(Context context){
        mInflater = LayoutInflater.from(context);
        this.context = context;

    }

}
