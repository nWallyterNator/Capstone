package com.example.myschoolapp.Activity.Search;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myschoolapp.Activity.MainActivity;
import com.example.myschoolapp.R;

public class ConfirmationScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation_screen);
    }

    /***
     ** 1. - functionality with the menu button
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_confirmation, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        // going to test details screen to add a test


        if (menuItem.getItemId() == R.id.homePageFromConfirmation) {
            Intent goBackToHomePage = new Intent(ConfirmationScreen.this, MainActivity.class);

            Toast.makeText(ConfirmationScreen.this,
                    // test to make sure it go to the page
                    "Going Back To the Home Page",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToHomePage);

            return true;
        }

        return true;
    }

}



