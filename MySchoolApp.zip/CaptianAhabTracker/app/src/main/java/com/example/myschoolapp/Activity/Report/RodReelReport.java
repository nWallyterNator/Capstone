package com.example.myschoolapp.Activity.Report;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.RodAndReel;

import java.util.List;

public class RodReelReport extends AppCompatActivity {

    private Repository repository;
    private RodReelReportAdapter rodReelReportAdapter;

    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rod_reel_report);



        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        repository = new Repository(getApplication());
        List<RodAndReel> allRodAndReels = repository.getmAllRodsAndReels();

        recyclerView = findViewById(R.id.recyclerViewForReport);

        rodReelReportAdapter = new RodReelReportAdapter(this, allRodAndReels);
        recyclerView.setAdapter(rodReelReportAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
        }

        return true;
    }

}
