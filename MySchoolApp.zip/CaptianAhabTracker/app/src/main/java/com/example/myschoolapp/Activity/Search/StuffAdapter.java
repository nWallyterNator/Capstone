package com.example.myschoolapp.Activity.Search;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myschoolapp.R;

import java.util.List;

public class StuffAdapter extends ArrayAdapter<Stuff> {




    public StuffAdapter(Context context, int resource, List<Stuff> stuffList) {

        super(context, resource, stuffList);

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Stuff stuff = getItem(position);

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.stuff_cell, parent, false);
        }

        TextView textView = (TextView)convertView.findViewById(R.id.stuffName);

        ImageView imageView = (ImageView)convertView.findViewById(R.id.stuffImage);

        textView.setText(stuff.getName());

        imageView.setImageResource(stuff.getImage());




        return convertView;
    }


}
