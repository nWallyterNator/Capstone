package com.example.myschoolapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Bait;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/
public class Baits extends AppCompatActivity {
    Button cancelBaitsBtn, addBaitsBTT;

    // need to add a repository for the recylcerview on this page
    Repository repository;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baits);

        addBaitsBTT = findViewById(R.id.addBaitDetailBTT);

        addBaitsBTT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToBaitDetails = new Intent(Baits.this, BaitDetailPage.class);


                Toast.makeText(Baits.this,
                        // test to make sure it go to the page
                        "Going to bait detail page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToBaitDetails);

            }
        });
        /***
         ** - 1. having Cancel Button go Back to main Page
         */
        // need to go back to the main page after Canceling
      cancelBaitsBtn = findViewById(R.id.cancelBaitsBTT);
        cancelBaitsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBackFromBaits = new Intent(Baits.this,MainActivity.class);
                {
                    Toast.makeText(Baits.this,
                            // test to make sure it go to the page
                            "Canceling Request",
                            Toast.LENGTH_SHORT).show();
                    startActivity(goBackFromBaits);
                }
            }
        });


        /***
         ** 2. need to create the recycler view and populate it
         ** - will query the database or put something on it
         ** - adding with the getAll
         ** - need to call the baits adapter
         ** - need to set the recycler view to the adapter
         ** - layout manager needs to be set to recyclerView
         ** - using the set adapter method to bring items onto list
         */

        RecyclerView baitsRecyclerView = findViewById(R.id.baitListRecyclerView);

        // querying the database
        repository = new Repository(getApplication());

        //  need to get it from the repository and put it on the list
        List<Bait> allAvailableTests = repository.getmAllBait();

        // baitAdapter
        final BaitsAdapter baitsAdapter = new BaitsAdapter(this);

        // setting on the recyclerView
        baitsRecyclerView.setAdapter(baitsAdapter);

        // layout view to recycler view
        baitsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // adapter.set method
       baitsAdapter.setBaits(allAvailableTests);









    }


    /****
     *** end of the line
     *** don't continue
     **/
    /*+=!^^^!=++=!^^^!=+  REQUIREMENTS    +=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=+
    - need to send alerts for the beginning and end


    +=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=+
  */
}