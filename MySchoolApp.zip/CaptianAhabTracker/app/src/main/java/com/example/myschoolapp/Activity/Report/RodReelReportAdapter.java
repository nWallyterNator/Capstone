package com.example.myschoolapp.Activity.Report;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.RodAndReel;

import java.util.List;

public class RodReelReportAdapter extends RecyclerView.Adapter<RodReelReportAdapter.ViewHolder> {

    Context context;
    List<RodAndReel> rodAndReelList;

    public RodReelReportAdapter(Context context, List<RodAndReel> rodAndReelList) {
        this.context = context;
        this.rodAndReelList = rodAndReelList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_report_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        if (rodAndReelList != null && rodAndReelList.size() > 0) {

            RodAndReel rodAndReel = rodAndReelList.get(position);
            holder.rodAndReelNameItem.setText(rodAndReel.getRodAndReelName());
            holder.rodAndReelCreateDateItem.setText(rodAndReel.getCreatedDateForReport());

        } else {

            return;

        }

    }

    @Override
    public int getItemCount() {
        return rodAndReelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView rodAndReelNameItem, rodAndReelCreateDateItem;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            rodAndReelNameItem = itemView.findViewById(R.id.rodAndReelNameItem);
            rodAndReelCreateDateItem = itemView.findViewById(R.id.rodAndReelCreateDateItem);

        }
    }
}
