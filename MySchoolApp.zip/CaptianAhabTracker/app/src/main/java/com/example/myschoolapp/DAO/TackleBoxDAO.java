package com.example.myschoolapp.DAO;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.myschoolapp.entities.TackleBox;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/



@Dao
public interface TackleBoxDAO {

    /***
     ** 1. - update, insert, delete, get all courses
     */


    // based on the video adding the @Insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertTackleBox(TackleBox tackleBox);

    // adding the update
    @Update
    void updateTackleBox(TackleBox tackleBox);

    // deleting the tackleBox
    @Delete void deleteTackleBox(TackleBox tackleBox);

    // get all tackleboxes
    @Query("Select * FROM tackleBoxes ORDER BY tackleBoxID ASC")
    List<TackleBox> getAllTackleBoxes();
    @Query ("SELECT * FROM tackleBoxes WHERE rodAndReelID= :rodAndReelID ORDER BY tackleBoxID ASC")
    List<TackleBox> getAllFilteredTackle(int rodAndReelID);

    @Query("SELECT * FROM tackleBoxes WHERE rodAndReelID = :rodAndReelID ")
    List<TackleBox> getRodAndTackle(int rodAndReelID);



    /****
     *** end of the line
     *** don't continue
     **/
}
