package com.example.myschoolapp.entities;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

/****
 *** @author Nicholas Walters
 **/

@Entity(tableName = "rods")
public class RodAndReel {
    /***
     ** 1. - need rod/reel name, beginning date, end date
     */
    // per the video used an id, my table doesn't have one but maybe I still need it
    @PrimaryKey(autoGenerate = true)
    private int rodAndReelID;

    private String rodAndReelName;

    private String startRodAndReelDay, endRodAndReelDay;

    /*****
     **********
     ********************/
    private String createdDateForReport;




    /**
     ** 2. - generating the getters and setters
     */
    public int getRodAndReelID() {
        return rodAndReelID;
    }

    public void setRodAndReelID(int rodAndReelID) {
        this.rodAndReelID = rodAndReelID;
    }

    public String getRodAndReelName() {
        return rodAndReelName;
    }

    public void setRodAndReelName(String rodAndReelName) {
        this.rodAndReelName = rodAndReelName;
    }

    public String getStartRodAndReelDay() {
        return startRodAndReelDay;
    }

    public void setStartRodAndReelDay(String startRodAndReelDay) {
        this.startRodAndReelDay = startRodAndReelDay;
    }

    public String getEndRodAndReelDay() {
        return endRodAndReelDay;
    }

    public void setEndRodAndReelDay(String endRodAndReelDay) {
        this.endRodAndReelDay = endRodAndReelDay;
    }

    public String getCreatedDateForReport() {
        return createdDateForReport;
    }

    public void setCreatedDateForReport(String createdDateForReport) {
        this.createdDateForReport = createdDateForReport;
    }

    /***
     ** 3. - generating the constructor
     */

    public RodAndReel(int rodAndReelID, String rodAndReelName, String startRodAndReelDay, String endRodAndReelDay, String createdDateForReport) {
        this.rodAndReelID = rodAndReelID;
        this.rodAndReelName = rodAndReelName;
        this.startRodAndReelDay = startRodAndReelDay;
        this.endRodAndReelDay = endRodAndReelDay;
        this.createdDateForReport = createdDateForReport;
    }



    @Override
    public String toString() {
        return "RodAndReel{" +
                "termID=" + rodAndReelID +
                ", termName='" + rodAndReelName + '\'' +
                ", termStart='" + startRodAndReelDay + '\'' +
                ", termEnd='" + endRodAndReelDay + '\'' +
                '}';
    }
    /****
 *** end of the line
 *** don't continue
 **/
    }


