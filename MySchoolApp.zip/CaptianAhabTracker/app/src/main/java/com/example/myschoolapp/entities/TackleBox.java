package com.example.myschoolapp.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/****
 *** @author Nicholas Walters
 **/


@Entity(tableName = "tackleBoxes")
public class TackleBox {
    /***
     ** 1. - need tackle box name
     **    - course id pk
     **    - start and end days
     **    - Manufacturers name, phone, email
     **    -  Notes
     **    - Tackle Status
     **    - RodAndReel id( foreign key ish)
      */


    @PrimaryKey(autoGenerate = true)
    private int tackleBoxID;

    private String tackleBoxName;

    private String tackleBoxStartDay, tackleBoxEndDay;

    private String manufacturerName, manPhoneNumber, manEmailAddress;

    private String notes;

    private String status;

    private int rodAndReelID;


/***
 ** 2. - need to generate constructor
 */
    public TackleBox(int tackleBoxID, String tackleBoxName, String tackleBoxStartDay, String tackleBoxEndDay, String manufacturerName, String manPhoneNumber, String manEmailAddress, String notes, String status, int rodAndReelID) {
        this.tackleBoxID = tackleBoxID;
        this.tackleBoxName = tackleBoxName;
        this.tackleBoxStartDay = tackleBoxStartDay;
        this.tackleBoxEndDay = tackleBoxEndDay;
        this.manufacturerName = manufacturerName;
        this.manPhoneNumber = manPhoneNumber;
        this.manEmailAddress = manEmailAddress;
        this.notes = notes;
        this.status = status;
        this.rodAndReelID = rodAndReelID;
    }
    /***
     ** 3. - generate the getters and setters
     */
    public int getTackleBoxID() {
        return tackleBoxID;
    }

    public void setTackleBoxID(int tackleBoxID) {
        this.tackleBoxID = tackleBoxID;
    }

    public String getTackleBoxName() {
        return tackleBoxName;
    }

    public void setTackleBoxName(String tackleBoxName) {
        this.tackleBoxName = tackleBoxName;
    }

    public String getTackleBoxStartDay() {
        return tackleBoxStartDay;
    }

    public void setTackleBoxStartDay(String tackleBoxStartDay) {
        this.tackleBoxStartDay = tackleBoxStartDay;
    }

    public String getTackleBoxEndDay() {
        return tackleBoxEndDay;
    }

    public void setTackleBoxEndDay(String tackleBoxEndDay) {
        this.tackleBoxEndDay = tackleBoxEndDay;
    }

    public String getManufacturerName() {
        return manufacturerName;
    }

    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    public String getManPhoneNumber() {
        return manPhoneNumber;
    }

    public void setManPhoneNumber(String manPhoneNumber) {
        this.manPhoneNumber = manPhoneNumber;
    }

    public String getManEmailAddress() {
        return manEmailAddress;
    }

    public void setManEmailAddress(String manEmailAddress) {
        this.manEmailAddress = manEmailAddress;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getRodAndReelID() {
        return rodAndReelID;
    }

    public void setRodAndReelID(int rodAndReelID) {
        this.rodAndReelID = rodAndReelID;
    }


    /****
     *** end of the line
     *** don't continue
     **/
}
