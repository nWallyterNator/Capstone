package com.example.myschoolapp.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.Activity.Report.DValidator;
import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.TackleBox;
import com.example.myschoolapp.entities.RodAndReel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/****
 *** @author Nicholas Walters
 **/
public class RodAndReelDetailPage extends AppCompatActivity {

//    /***
//     ** - 1. need a recyclcyerView to add the associated tackle
//     */


    // 2 visible buttons, save Rod/reel Details and cancel button
    Button saveRodAndReelBtn, cancelBtn;
    // making the repository to test it
    // this repository will go in the options button

    // need the current Rod/Reel from the list to delete
    RodAndReel crntRodAndReelDetails;

    // need the current number of bait for the delete to see if anything is attached to it
    int numberOfTackleAttached;

    Repository repository;
    // need a Rod/reel ID
    int rodReelID;


    // need a Rod/Reel
    RodAndReel rodAndReel;


    /************
     ***********
     */
    String createdDateForReport;


    /***
     ** 3. - adding things from the edit text part of the file
     ** -  there are 3 edit texts, name, begin and end date
     ** - section off begin and end date so that I can see it and will change it
     */
    // rod/reel name
    EditText changeRodReelName;


    /***
     ** 5. - can't get the dates to save trying again from the begining
     ** - need the textViews for the date
     ** - need datepickerdialogs
     ** - need calenders
     ** - Strings for end and begin
     */
    // textViews
    TextView changeBegDateForRodAndReels, changeEndDateForRodAndReels;

    // datepickerDialogs
    DatePickerDialog.OnDateSetListener beginRodDate, endRodDate;

    //Calenders
    final Calendar ReelStartCalendar = Calendar.getInstance();
    final Calendar ReelEndCalendar = Calendar.getInstance();

    // strings for start and begin date
    String startingReelDate, endingReelDate;


    /***
     ** 4. - senders for the recylcer view
     ** - need 3, rod/reel Name, begining date, end date
     ** - change beginning date, end date
     */
    // sending rod/reelName
    String rodAndReelName;


    // need the current date for report


    /************
     ***********
     */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rod_reel_detail_page);


        /************
         ***********
         */
        createdDateForReport = getIntent().getStringExtra("created");


        /***
         ** 6. - trying recyclerView because it wasn't populating before
         ** - tackle adapter
         ** - need the recylerview
         ** - need a list
         */


        // adding format for date and adding a string
        String myFormatForCalendar = "MM/dd/yy";
        // adding SimpleDateFormat
        SimpleDateFormat sdf = new SimpleDateFormat(myFormatForCalendar, Locale.US);

        /***
         ** 5. need to initalize by finding by id there
         ** - going to use the getIntent to get the values
         ** - after getting it you do .set text method
         ** - commenting out to run it all on the main screen
         */


        //name text view
        changeRodReelName = findViewById(R.id.changeRodNameTvRodAndReelsDetails);

        // rod name from the getintent
        rodAndReelName = getIntent().getStringExtra("name");

        // set text method
        changeRodReelName.setText(rodAndReelName);


        // need to get a rod ID
        rodReelID = getIntent().getIntExtra("id", -1);

        // getMethod for new Calender
        /***
         ** 6. getting a new calendar and set method
         */
        //ids
        changeBegDateForRodAndReels = findViewById(R.id.changeRodAndReelStartDayTvRodDetails);
        changeEndDateForRodAndReels = findViewById(R.id.changeRodAndReelEndDayTvRodAndReelDetails);


        //getting the info from the strings from the adapter
        startingReelDate = getIntent().getStringExtra("startingDate");
        endingReelDate = getIntent().getStringExtra("endingDate");


        // setting info using an if statement if its at -1
        if (rodReelID == -1) {
            changeBegDateForRodAndReels.setText(sdf.format(new Date()));
            changeEndDateForRodAndReels.setText(sdf.format(new Date()));
            // if it is found
            // else statement
        } else {
            changeEndDateForRodAndReels.setText(endingReelDate);
            changeBegDateForRodAndReels.setText(startingReelDate);
        }

        /***
         ** - start and end date making it a button
         */
        //start date
        changeBegDateForRodAndReels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeBegDateForRodAndReels.getText().toString();

                if (info.equals("")) info = "12/01/23";
                // try and catch statement
                try {
                    // calling the begin calendar
                    ReelStartCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog date picker
                new DatePickerDialog(RodAndReelDetailPage.this, beginRodDate,
                        ReelStartCalendar.get(Calendar.YEAR),
                        //month for calender
                        ReelStartCalendar.get(Calendar.MONTH),
                        // day of the month
                        ReelStartCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // end date button
        changeEndDateForRodAndReels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeEndDateForRodAndReels.getText().toString();

                if (info.equals("")) info = "12/01/23";
                //try and catch statement
                try {
                    //calling the end calender
                    ReelEndCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog datepicker
                new DatePickerDialog(RodAndReelDetailPage.this, endRodDate, ReelEndCalendar
                        .get(Calendar.YEAR),
                        //month
                        ReelEndCalendar.get(Calendar.MONTH),
                        // day
                        ReelEndCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // new end date new date picker dialog
        endRodDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year
                ReelEndCalendar.set(Calendar.YEAR, year);
                // month
                ReelEndCalendar.set(Calendar.MONTH, month);
                // day
                ReelEndCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update ending label
                updateEndingRodAndReelLabel();

            }


        };

        // new start date picker dialog
        beginRodDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year from the begin calendar
                ReelStartCalendar.set(Calendar.YEAR, year);
                // month
                ReelStartCalendar.set(Calendar.MONTH, month);
                // day
                ReelStartCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update start label method
                updateStartingRodAndReelLabel();

            }
        };


        /***
         ** - save button
         ** - need to do an if statement
         ** - doing an else statement
         ** - I want it to go back to the rod/reel list page after its done from saving
         */


        /***
         ** - 7. this if for the sample repository
         ** -  copying the code from the rod/reels page
         */
        repository = new Repository(getApplication());


        RecyclerView recyclerView = findViewById(R.id.recyclerViewForRodAndReelDetails);
        repository = new Repository(getApplication());
        // need tackle Adapter
        final TackleBoxesAdapter tackleBoxesAdapter = new TackleBoxesAdapter(this);
        recyclerView.setAdapter(tackleBoxesAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // new list for the filteredCourses
        List<TackleBox> filteredTackle = new ArrayList<>();
        // for loop
        for (TackleBox c : repository.getmAllTackleBoxes()) {
            if (c.getRodAndReelID() == rodReelID) filteredTackle.add(c);
        }
        tackleBoxesAdapter.setTackleBoxes(filteredTackle);
        /********************************/


        /************
         ***********
         */

    }


    /***
     ** - 4. making an option to create tackle
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_rod_and_reel_detail_page, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {


        if (menuItem.getItemId() == R.id.deleteRodRodAndReelDetailsPageMenuItem) {
            // deleting a rod/reel

            // using a for each loop
            for (RodAndReel trm : repository.getmAllRodsAndReels()) {
                if (trm.getRodAndReelID() == rodReelID) crntRodAndReelDetails = trm;
            }

            // need to check on if there are a number of tackle attached
            numberOfTackleAttached = 0;

            // need to do another for loop need to know which tackle are with each rod and reel
            for (TackleBox tackleBox : repository.getmAllTackleBoxes()) {
                // if tackle attached = to rod/reelId then increment
                if (tackleBox.getRodAndReelID() == rodReelID) ++numberOfTackleAttached;
            }
            if (numberOfTackleAttached == 0) {
                // if there aren't any tackle attached then you can delete
                repository.deleteRodAndReel(crntRodAndReelDetails);
                // adding toast message to show which reel got deleted
                Toast.makeText(RodAndReelDetailPage.this, crntRodAndReelDetails.getRodAndReelName() +
                        " was deleted from the list.", Toast.LENGTH_LONG).show();
                // going back to rods list
                Intent goBackToReelsScreen = new Intent(RodAndReelDetailPage.this, RodAndReels.class);
                startActivity(goBackToReelsScreen);

            }

            // creating another toast message to say  that you can't delete a reel with a tackle
            // attached to the rod and reel, delete the tackle first
            else {
                Toast.makeText(RodAndReelDetailPage.this,
                        "You can't delete the Rod and Reel. Please delete the associated tackle",
                        Toast.LENGTH_LONG).show();

                RecyclerView recyclerViewForTermDetails = findViewById(R.id.recyclerViewForRodAndReelDetails);
            }

        }


        if (menuItem.getItemId() == R.id.saveRodAndReelsDetailsBTT) {

            Date currentDateTime = Calendar.getInstance().getTime();
            String created_date = currentDateTime.toString();

            DValidator validator = new DValidator();



            // need to make sure that rod id is found
            if (rodReelID == -1) {
                // if  rod isn't found create new rod and reel
                rodAndReel = new RodAndReel(0, changeRodReelName.getText().toString(),
                        changeBegDateForRodAndReels.getText().toString(),
                        changeEndDateForRodAndReels.getText().toString(), created_date);
                // need to insert the new rod and reel into the repository
                repository.insertRodAndReel(rodAndReel);

                // going back to the screen to refresh so we can see if it worked vs going back and forth
                Intent goBackWithSavedRodAndReel = new Intent(RodAndReelDetailPage.this,
                        RodAndReels.class);
                startActivity(goBackWithSavedRodAndReel);


            }
            // else if it is found then we will update the rod and reel
            else {
                rodAndReel = new RodAndReel(rodReelID, changeRodReelName.getText().toString(),
                        changeBegDateForRodAndReels.getText().toString(),
                        changeEndDateForRodAndReels.getText().toString(), created_date);
                // update rodAndReel in repository
                repository.updateRodAndReel(rodAndReel);

                // going back to the screen to refresh so we can see if it worked vs going back and forth
                Intent goBackWithSavedTerm = new Intent(RodAndReelDetailPage.this,
                        RodAndReels.class);
                startActivity(goBackWithSavedTerm);
            }


        }

        if (menuItem.getItemId() == R.id.cancelRodReelDetailBTT) {
            Intent goBackToTerms = new Intent(RodAndReelDetailPage.this, RodAndReels.class);

            Toast.makeText(RodAndReelDetailPage.this,
                    // test to make sure it go to the page
                    "Canceling Request",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToTerms);
        }

        if (menuItem.getItemId() == R.id.homePageFromRodAndReelDetail) {
            Intent goBackToHomePage = new Intent(RodAndReelDetailPage.this, MainActivity.class);

            Toast.makeText(RodAndReelDetailPage.this,
                    // test to make sure it go to the page
                    "Going Back To the Home Page",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToHomePage);

            return true;
        }


        return true;


    }




    /*$%^^%$$%^^%$ $%^^%$    METHODS    $%^^%$ $%^^%$ $%^^%$ $%^^%$

    $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ */

    private void updateEndingRodAndReelLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeEndDateForRodAndReels.setText(sdf.format(ReelEndCalendar.getTime()));


    }

    private void updateStartingRodAndReelLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeBegDateForRodAndReels.setText(sdf.format(ReelStartCalendar.getTime()));
    }




    /****
     *** end of the line
     *** don't continue
     **/

    /*$%^^%$$%^^%$ $%^^%$    REQUIREMENTS    $%^^%$ $%^^%$ $%^^%$ $%^^%$
    - need to be able add as many rods and reels as I can
    - display a list that goes along with each tackle
    - need to be delete, add, and update

    $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ */


}