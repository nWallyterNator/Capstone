package com.example.myschoolapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myschoolapp.Activity.Report.RodReelReport;
import com.example.myschoolapp.Activity.Search.StuffMainActivity;
import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Bait;
import com.example.myschoolapp.entities.TackleBox;
import com.example.myschoolapp.entities.RodAndReel;

import java.util.Calendar;
import java.util.Date;

/****
 *** @author Nicholas Walters
 **/
public class MainActivity extends AppCompatActivity {
    // static number from tackleBox page start date
    public static int numStartAlertTackleBox;

    // static number from tackleBox details page end date
    public static int numEndAlertTackleBox;

    // static number from test page start date
    public static int numStartAlertTest;

    // static number from test details page end date
    public static int numEndAlertTest;


    /**
     * * 7. - need test begin and end date alert as well
     */


    Button termsButHome, coursesButHome, testsButHome, searchEverythingBtn;
    TextView homePageText;

    // adding a repository
    Repository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /****
         *** Need this to go to the rodAndReels page
         **/
        //rodAndReel button
        termsButHome = findViewById(R.id.termBtn);
        termsButHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToTermsPage = new Intent(MainActivity.this, RodAndReels.class);

                Toast.makeText(MainActivity.this,
                        // test to make sure it go to the page
                        "Going to rodAndReels page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToTermsPage);

            }
        });


        // tackleBox button
        coursesButHome = findViewById(R.id.cancelTackleBtn);
        coursesButHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToCoursesPage = new Intent(MainActivity.this, TackleBoxes.class);
                Toast.makeText(MainActivity.this,
                        //test to make sure it goes to TackleBoxes page
                        "Going to the TackleBoxes page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToCoursesPage);
            }
        });

        // assessment button
        testsButHome = findViewById(R.id.testsBtn);
        testsButHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToTestsPage = new Intent(MainActivity.this, Baits.class);
                Toast.makeText(MainActivity.this,
                        //test to make sure it goes to the Tests page
                        "Going to the Bait page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToTestsPage);
            }
        });

        // search button
        searchEverythingBtn = findViewById(R.id.searchEverythingBtn);
        searchEverythingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToSearchPage = new Intent(MainActivity.this, StuffMainActivity.class);
                Toast.makeText(MainActivity.this,
                        //test to make sure it goes to the Tests page
                        "Let's Fill Up Our Inventory",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToSearchPage);
            }
        });


    }

    /***
     ** 2. - checking to make sure the database will run from this screen
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.sampleTermTermDetMenuIt) {
            repository = new Repository(getApplication());


            /***
             ** 4. Add sample
             ** couple of rodAndReels
             */
            Date currentDateTime = Calendar.getInstance().getTime();
            String created_date = currentDateTime.toString();

            RodAndReel rodAndReel = new RodAndReel(0, "Easy RodAndReel",
                    "October 1 2012", "December 25, 2017",created_date);
            repository.insertRodAndReel(rodAndReel);
            RodAndReel rodAndReel1 = new RodAndReel(1, "Sage RodAndReel",
                    "10/01/2023", "12/15/2023",created_date);
            repository.insertRodAndReel(rodAndReel1);

            RodAndReel rodAndReel2 = new RodAndReel(2, "Kids RodAndReel",
                    "Nov 24,2016", "Oct 21,2018",created_date);
            repository.insertRodAndReel(rodAndReel2);
            RodAndReel rodAndReel3 = new RodAndReel(3, " Rhino RodAndReel",
                    "12/04/2011", "12/05/2011",created_date);
            repository.insertRodAndReel(rodAndReel3);
            RodAndReel rodAndReel4 = new RodAndReel(4, "Ugly Stick RodAndReel",
                    "10-01-2024", "10-02-2024",created_date);
            repository.insertRodAndReel(rodAndReel4);


            /***
             ** 5. add sample
             ** couple of tackleBoxes
             ** moving this into tackleBox Details menu and commenting out
             */
            TackleBox tck1 = new TackleBox(0, "hooks", "October 23, 1995", "October 24, 1996",
                    "Agent Smith", "912-456-5644",
                    "mrAnderson@theMatrixisReal.com",
                    "is there a spoon", "fixed", 0
            );
            repository.insertTackleBox(tck1);

            TackleBox tck2 = new TackleBox(1, "Sinker Weights", "12/01/01",
                    "12/04/02", "Professor Proton",
                    "801-555-5555",
                    "mathisfun@profProton.com",
                    "easily brakes",
                    "broken",
                    1);
            repository.insertTackleBox(tck2);

            TackleBox tck3 = new TackleBox(2, "Blue TackleBox", "01-10-2011",
                    "12-02-2021", "DOD", "444-444-4444",
                    "classified@no.com", "fix it fast please",
                    "given to customer", 2);
            repository.insertTackleBox(tck3);

            TackleBox tck4 = new TackleBox(3, "The All In One TackleBox", "May 5 2015",
                    "July 6 2016", "ArmyHammer", "111-111-1111",
                    "stayClean@yahoo.com", "always calling",
                    "plan to fix", 3);
            repository.insertTackleBox(tck4);

            TackleBox tck5 = new TackleBox(4, "Cabellas Soft TackleBox", "04/03/2022",
                    "05/06/2022", "Ms. Bombadil",
                    "333-333-4444", "ringadongDillo@shire.uk",
                    "very nice person", "fixed", 4);
            repository.insertTackleBox(tck5);


            /***
             ** 6. add sample
             ** couple of Bait
             */
            Bait bt1 = new Bait(0, "NightCrawlers", "Oct 13, 2025", "OCt 17, 2026", "Live Bait", 0);
            repository.insertBait(bt1);

            Bait bt2 = new Bait(1, "Jakes Spinner", "11/01/01",
                    "11/02/03", "Artificial Bait", 1);
            repository.insertBait(bt2);

            Bait bt3 = new Bait(2, "Spoons", "Oct 12, 2011",
                    "Oct 13, 2012", "Artificial Bait", 2);
            repository.insertBait(bt3);

            Bait bt4 = new Bait(3, "Salmon Eggs", "December 24, 2023",
                    "December 25, 2023", " Live Bait", 3);
            repository.insertBait(bt4);

            Bait bt5 = new Bait(4, "Squid Jig", "09/11/2022",
                    "09/12/2022", "Artificial Bait", 4);
            repository.insertBait(bt5);


            return true;
        }


        if (menuItem.getItemId() == R.id.reportsFromMainMenu) {
            Intent goToReportScreen = new Intent(MainActivity.this, RodReelReport.class);

            Toast.makeText(MainActivity.this,
                    // test to make sure it go to the page
                    "Generating A Report",
                    Toast.LENGTH_SHORT).show();
            startActivity(goToReportScreen);
        }

        return true;
    }




/****
 *** end of the line
 *** don't continue
 **/

     /*#^#^#^#^#^#^##^#^#^#^ REQUIREMENTS  ^#^#^#^#^#^#^#^#^#^#^#^#
    - main screen = home screen
    - need to make the buttons go to each Activity
    - Requirement B homescreen = activity_main


    ^##^#^#^#^#^#^#^#^#^##^^##^#^#^#^#^#^#^#^#^##^^##^#^#^#^#^#^#^#^#^#
  */
}