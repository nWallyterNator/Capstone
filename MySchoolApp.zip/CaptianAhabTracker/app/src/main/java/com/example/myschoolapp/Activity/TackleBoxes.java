package com.example.myschoolapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.TackleBox;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/
public class TackleBoxes extends AppCompatActivity {

    // I have 2 buttons
    Button homeTackleBtn, addTackleDetailBtn;

    // need to declare a repository for the repository on this page
    Repository courseRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tackleboxes);

        /***
         ** 2.this will go to the tackle detail page
         */
        addTackleDetailBtn = findViewById(R.id.goToTackleDetail);
        addTackleDetailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent goToTackleDetailPage = new Intent(TackleBoxes.this, TackleBoxDetailPage.class);

               Toast.makeText(TackleBoxes.this,
                        // test to make sure it go to the page
                       "Going to Tackle Detail Page",
                       Toast.LENGTH_SHORT).show();
               startActivity(goToTackleDetailPage);

            }

        });

        // need to go back to the main page after Canceling
        homeTackleBtn = findViewById(R.id.cancelTackleBtn);
        homeTackleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBackFromTackleboxes = new Intent(TackleBoxes.this, MainActivity.class);
                {
                    Toast.makeText(TackleBoxes.this,
                            // test to make sure it go to the page
                            "Canceling Request",
                            Toast.LENGTH_SHORT).show();
                    startActivity(goBackFromTackleboxes);
                }
            }
        });


        /***
         ** 3. need to create the recycler view and populate it
         ** - will query the database or put something on it
         ** - adding with the getAll
         ** - need to call the tackle adapter
         ** - need to set the recycler view on the adapter
         ** - layout manager needs to be set to recyclerView
         ** - will use the adapter.set method to put the actual list on
         */
        RecyclerView courseRecyclerView = findViewById(R.id.tackleboxesRecylerView);

        // querying the database
        courseRepository = new Repository(getApplication());

        //  need to get it from the repository and put it on the list
        List<TackleBox> allAvailableCours = courseRepository.getmAllTackleBoxes();


        // tackleAdapter
       final TackleBoxesAdapter tackleBoxesAdapter = new TackleBoxesAdapter(this);

        // set recyclerview to adapter
        courseRecyclerView.setAdapter(tackleBoxesAdapter);

        // layout view to recycler view
        courseRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // adapter set method to populate list
        tackleBoxesAdapter.setTackleBoxes(allAvailableCours);


    }


    /***
     ** 3. - functionality with the menu button
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_tackleboxes, menu);
        return true;
    }

    /***
     ** 4. - this will take it to the tackle box list page
     */
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        // going to test details screen to add a test
        if (menuItem.getItemId() == R.id.baitMenuPage) {
            Intent goToTestDetailScreen = new Intent(TackleBoxes.this, Baits.class);

            Toast.makeText(TackleBoxes.this,
                    // test to make sure it go to the page
                    "Adding Test",
                    Toast.LENGTH_SHORT).show();
            startActivity(goToTestDetailScreen);
        }

        return true;
    }


        /****
         *** end of the line
         *** don't continue
         **/

      /*%$%^$$$%%$%^$$$%^^^$$#^ REQUIREMENTS  %$%^$$$%^^^$$#%$%^$$$%^^^$$#
    - need to be able to add as many tackleboxes as needed
    - list of tackle boxes with the rod and reels
    - need tackle box  title
    - need tackle box order date, sold date,
    - need tackle status which will either be
        --still working on it, repaired, returned, planning on fixing
    -  manufacture w/
        - name
        - phone number
        - email address
    - Requirement B needs list of tackleboxes


    ^#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#
  */
}