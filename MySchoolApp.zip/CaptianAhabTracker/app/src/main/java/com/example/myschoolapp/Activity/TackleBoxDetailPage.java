package com.example.myschoolapp.Activity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Bait;
import com.example.myschoolapp.entities.RodAndReel;
import com.example.myschoolapp.entities.TackleBox;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TackleBoxDetailPage extends AppCompatActivity {

    List<RodAndReel> rodsForSpinner;
    Repository repository;

    // need a TackleBox ID
    int tackleBoxID;
    /***
     ** - 1. couldn't get the start and end dates to work, commenting out
     ** - trying again
     ** - need textviews start and end, datepicker start and end,strings start and end,calendars start and end
     */
    //text View begin date and end date
    TextView changeBegDateForTackleBox, changeEndDateForTackleBox;
    // datepicker start and end
    DatePickerDialog.OnDateSetListener beginTackleBoxDetailDate, endTackleBoxDetailDate;
    // strings start and end
    String startingTackleBoxDetailDate, endingTackleBoxDetailDate;
    // calender start and end
    final Calendar tackleBoxDetailsStartCalendar = Calendar.getInstance();
    final Calendar tackleBoxDetailsEndCalendar = Calendar.getInstance();


    /***
     ** - 2. need to do 7 things to declare
     ** - tackleBox name, start and end days,
     ** - instructor name, email and phone
     ** - tackleBox notes and tackleBox status
     ** - rod and reel id
     */
// tackle box info
    // tackle box name
    EditText changeTackleBoxName;

    // need spinner for rod and reel
    Spinner spinner2;


    //manufacturers  info

    // man name

    EditText changeManName;

    // man email
    EditText changeManEmail;

    // man phone
    EditText changeManPhone;


    //random info

    //  notes
    EditText changeNote;


    // need bait Id
    int baitID;

    //  need tacklebox object
    TackleBox tackleBox;
    int rodAndReelID;

    // need a crnt tacklebox  to delete
    TackleBox crntCrs;
    // need the current number of bait to delete to see if anything is attached to it
    int numberOfBaitAttached;

    List<RodAndReel> rodAndReels;

    List<TackleBox> allCours;

    // need chosen rodAndReel
    String chosenTerm;


    //Spinnner for tackle boxes
    // need string for tackle box
    Spinner tackleBoxStatusSpinner;
    String tackleBoxStatus;


    /***
     ** 3. - senders for the recylcer view
     ** - need 7, tackle Box Name, beginning date, end date
     ** -  tackle name, start and end days,
     ** - manufacturer  name, email and phone
     ** -  notes and status
     ** - rod/reel id
     */

    //tackle box name, begin date, end date
    String tackleBoxName;


    // manufacturer name, email and phone
    String manName, manEmail, manPhone;

    // random notes and status
    String notes, status;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tacklebox_detail_page);
        /***
         ** 1. - rod/reel spinnner
         ** - need id
         ** - array list
         */
//        //id and cast
//


        /*********************************************** */
        // Status Spinner
        // find the id
        tackleBoxStatusSpinner = findViewById(R.id.statusSpinner);

        // get the information
        tackleBoxStatus = getIntent().getStringExtra("courseStatus");

        // need array adapter
        ArrayAdapter<CharSequence> adapterTackleboxStatus = ArrayAdapter.createFromResource(this,
                R.array.status_list,
                android.R.layout.simple_spinner_dropdown_item);
        adapterTackleboxStatus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tackleBoxStatusSpinner.setAdapter(adapterTackleboxStatus);

        repository = new Repository(getApplication());


        if (tackleBoxID != -1) {
            int tackleBoxStatusPosition = adapterTackleboxStatus.getPosition(tackleBoxStatus);
            tackleBoxStatusSpinner.setSelection(tackleBoxStatusPosition);

        }

        /*********************************************** */


        /*****^%^%^%$%^$%^$%$%$%%$ rod/reel spinner */

        // need to call the id
        spinner2 = findViewById(R.id.rodAndReelSpinnerFromTackleBoxDetails);

        // will create a method to get a spinner
        // calling spinner
        createSpinner();


        // need to make the spinner clickable
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // getting a new rod/reel
                // getting i which is the position
                RodAndReel chosenRodAndReel = rodAndReels.get(i);
                rodAndReelID = chosenRodAndReel.getRodAndReelID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /**%###$#$##$##########################$#%#$#%#%#$#$##%#%$#*/


        // adding format for date and adding a string
        String myFormatForCalendar = "MM/dd/yy";
        // adding SimpleDateFormat
        SimpleDateFormat sdf = new SimpleDateFormat(myFormatForCalendar, Locale.US);

        /***
         ** 4. - intializing by finding all of them from above
         ** - 7 are needed
         ** -  will do the getIntent method
         ** -  .setText method
         */
        // tackle box name
        changeTackleBoxName = findViewById(R.id.changeTackleBoxNameTvTackleBoxDetails);
        // getIntent for name
        tackleBoxName = getIntent().getStringExtra("name");
        // setText for name
        changeTackleBoxName.setText(tackleBoxName);

        // getIntent for status
        status = getIntent().getStringExtra("courseStatus");

        /***
         ** 5. - need to get the dates
         */
        // finding ids - begindate
        changeBegDateForTackleBox = findViewById(R.id.changeTackleBoxStartDayTvTackleBoxDetails);
        changeEndDateForTackleBox = findViewById(R.id.changeTackleBoxEndDayTvTackleBoxDetails);

        //getting the info from the strings from the adapter
        startingTackleBoxDetailDate = getIntent().getStringExtra("beginDate");
        endingTackleBoxDetailDate = getIntent().getStringExtra("endDate");

        // setting info using an if statement if its at -1
        if (tackleBoxID == -1) {
            changeBegDateForTackleBox.setText(sdf.format(new Date()));
            changeEndDateForTackleBox.setText(sdf.format(new Date()));
            // if it is found
            // else statement
        } else {
            changeEndDateForTackleBox.setText(endingTackleBoxDetailDate);
            changeBegDateForTackleBox.setText(startingTackleBoxDetailDate);
        }

        /***
         ** - start and end date making it a button
         */
        //start date
        changeBegDateForTackleBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeBegDateForTackleBox.getText().toString();

                if (info.equals("")) info = "12/01/23";
                // try and catch statement
                try {
                    // calling the begin calendar
                    tackleBoxDetailsStartCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog date picker
                new DatePickerDialog(TackleBoxDetailPage.this, beginTackleBoxDetailDate,
                        tackleBoxDetailsStartCalendar.get(Calendar.YEAR),
                        //month for calender
                        tackleBoxDetailsStartCalendar.get(Calendar.MONTH),
                        // day of the month
                        tackleBoxDetailsStartCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // end date button
        changeEndDateForTackleBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeEndDateForTackleBox.getText().toString();

                if (info.equals("")) info = "12/01/23";
                //try and catch statement
                try {
                    //calling the end calender
                    tackleBoxDetailsEndCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog datepicker
                new DatePickerDialog(TackleBoxDetailPage.this, endTackleBoxDetailDate, tackleBoxDetailsEndCalendar
                        .get(Calendar.YEAR),
                        //month
                        tackleBoxDetailsEndCalendar.get(Calendar.MONTH),
                        // day
                        tackleBoxDetailsEndCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // new end date new date picker dialog
        endTackleBoxDetailDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year
                tackleBoxDetailsEndCalendar.set(Calendar.YEAR, year);
                // month
                tackleBoxDetailsEndCalendar.set(Calendar.MONTH, month);
                // day
                tackleBoxDetailsEndCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update ending label
                updateEndingTackleBoxDetailsLabel();

            }


        };


        // new start date picker dialog
        beginTackleBoxDetailDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year from the begin calendar
                tackleBoxDetailsStartCalendar.set(Calendar.YEAR, year);
                // month
                tackleBoxDetailsStartCalendar.set(Calendar.MONTH, month);
                // day
                tackleBoxDetailsStartCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update start label method
                updateStartingTackleBoxDetailsLabel();

            }
        };


        //instructor info name
        changeManName = findViewById(R.id.changeManNameTvTackleboxDetails);
        // getIntent for teacherName
        manName = getIntent().getStringExtra("courseInstructorName");
        // setText for teacherName
        changeManName.setText(manName);


        // instructor phone number
        changeManPhone = findViewById(R.id.changeManPhoneTvTackleboxDetails);
        // get intent for teacher phone
        manPhone = getIntent().getStringExtra("courseInstructorPhoneNumber");
        // settext for phone
        changeManPhone.setText(manPhone);


        // instructors email
        changeManEmail = findViewById(R.id.changeManEmailTvTackleBoxDetails);
        //getIntent for email
        manEmail = getIntent().getStringExtra("courseInstructorEmail");
        // setText for email
        changeManEmail.setText(manEmail);


        // random info note
        changeNote = findViewById(R.id.changeNotesTvTackleBoxDetails);
        //getItent for Note
        notes = getIntent().getStringExtra("courseNotes");
        // setText for note
        changeNote.setText(notes);


        //ID
        tackleBoxID = getIntent().getIntExtra("id", -1);
        // rod/reel id
        rodAndReelID = getIntent().getIntExtra("termID", -1);


        /***
         ** - 1. adding the associated tackle box recycle view
         ** -  copying the code from the rods and reels page
         */
        RecyclerView baitRecyclerViewForDetailPage = findViewById(R.id.baitListRecyclerView);
// repository
        repository = new Repository(getApplication());
        // querying the database

        // need tackle box Adapter
        final BaitsAdapter baitsAdapter = new BaitsAdapter(this);
        baitRecyclerViewForDetailPage.setAdapter(baitsAdapter);
        baitRecyclerViewForDetailPage.setLayoutManager(new LinearLayoutManager(this));
        // new list for the filtered tackle boxes
        List<Bait> filteredBaits = new ArrayList<>();
        // for loop
        for (Bait t : repository.getmAllBait()) {
            if (t.getTackleBoxID() == tackleBoxID) filteredBaits.add(t);
        }
        baitsAdapter.setBaits(filteredBaits);
/***
 ** going to get a filtered list instead of all the bait
 */


    }


    /*(****)---(****)---     METHODS    (****)--- (****)--- (****)--- (****)---

            (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)---  */


    private void updateStartingTackleBoxDetailsLabel() {
        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeBegDateForTackleBox.setText(sdf.format(tackleBoxDetailsStartCalendar.getTime()));
    }

    private void updateEndingTackleBoxDetailsLabel() {
        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeEndDateForTackleBox.setText(sdf.format(tackleBoxDetailsEndCalendar.getTime()));
    }


    public void createSpinner() {
        // calling and updating the repository
        Repository repository = new Repository(getApplication());

        // getting rod and reels
        rodAndReels = repository.getmAllRodsAndReels();

        // creating a list of all rod/reels to hold it
        // I want the termNames to drop it down
        List<String> termNames = new ArrayList<>();

        // for loop to go through all of the rodAndReels to find the one that matches
        for (RodAndReel rodAndReel : rodAndReels) {
            termNames.add(rodAndReel.getRodAndReelName());
        }

        // adding the new adapter
        ArrayAdapter<String> termSpinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, termNames);
        spinner2.setAdapter(termSpinnerAdapter);
    }


    public boolean onCreateOptionsMenu(Menu tackleBoxDetailMenu) {
        getMenuInflater().inflate(R.menu.menu_tacklebox_detail_page, tackleBoxDetailMenu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem tackleBodMenuItemToPick) {
        if (tackleBodMenuItemToPick.getItemId() == R.id.cancelItemForTackleBoxDetails) {
            Intent goBackToTackleBoxes = new Intent(TackleBoxDetailPage.this, TackleBoxes.class);
            Toast.makeText(TackleBoxDetailPage.this,
                    // test to make sure it go to the page
                    "Canceling Request",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToTackleBoxes);

            return true;
        }
        /***
         ** 5. - save button that will save the list
         */
        if (tackleBodMenuItemToPick.getItemId() == R.id.saveTackleBox) {
            if (tackleBoxID == -1) {
                // if status is found
//
                // if box isn't found create new tackle box
                tackleBox = new TackleBox(0, changeTackleBoxName.getText().toString(),
                        changeBegDateForTackleBox.getText().toString(),
                        changeEndDateForTackleBox.getText().toString(),
                        changeManName.getText().toString(),
                        changeManPhone.getText().toString(),
                        changeManEmail.getText().toString(),
                        changeNote.getText().toString(),
                        tackleBoxStatusSpinner.getSelectedItem().toString(), rodAndReelID);
                // need to insert the new tackle box into the repository
                repository.insertTackleBox(tackleBox);

            } else {
                tackleBox = new TackleBox(tackleBoxID, changeTackleBoxName.getText().toString(),
                        changeBegDateForTackleBox.getText().toString(),
                        changeEndDateForTackleBox.getText().toString(),
                        changeManName.getText().toString(),
                        changeManPhone.getText().toString(),
                        changeManEmail.getText().toString(),
                        changeNote.getText().toString(),
                        tackleBoxStatusSpinner.getSelectedItem().toString(), rodAndReelID);
                repository.updateTackleBox(tackleBox);
            }
            /***
             ** 8. going to go back to the tackle box  list screen
             */


            Intent goBackToTackleBoxesList = new Intent(TackleBoxDetailPage.this, TackleBoxes.class);
            startActivity(goBackToTackleBoxesList);
        }
        /***
         ** 6. - share note
         */
        if (tackleBodMenuItemToPick.getItemId() == R.id.shareNoteItem) {

            // added note field
            Intent sentNoteIntent = new Intent();

            sentNoteIntent.setAction(Intent.ACTION_SEND);
            sentNoteIntent.putExtra(Intent.EXTRA_TEXT,
                    "I am sharing Notes from " + changeTackleBoxName.getText().toString() + ": " +
                            changeNote.getText().toString());
            sentNoteIntent.putExtra(Intent.EXTRA_TITLE,
                    "Sharing Notes");

            sentNoteIntent.setType("text/plain");

            Intent shareIntent = Intent.createChooser(sentNoteIntent, null);

            startActivity(shareIntent);

            return true;
        }

        /***
         ** 8. - need to add the alert me menu start date
         */
        if (tackleBodMenuItemToPick.getItemId() == R.id.notifyStartTackleBoxDetails) {

            // begin date for fishing lessons
            String startFishingLessonsDateFromBefore = changeBegDateForTackleBox.getText().toString();

            String myTackleBoxDetailsBeginFormat = "MM/dd/yy";

            SimpleDateFormat sdf = new SimpleDateFormat(myTackleBoxDetailsBeginFormat, Locale.US);

            Date tackleBoxDetailsBeginDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                tackleBoxDetailsBeginDateForHere = sdf.parse(startFishingLessonsDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long trigger = tackleBoxDetailsBeginDateForHere.getTime();
            // need to build the receiver
            Intent receiveMessageFromReceiverBeg = new Intent(TackleBoxDetailPage.this, MyReceiver.class);
            // message to add on what I want them to see
            receiveMessageFromReceiverBeg.putExtra("key", tackleBoxDetailsBeginDateForHere + "should trigger");

            // sender
            PendingIntent senderBeginTackleBox = PendingIntent.getBroadcast(TackleBoxDetailPage.this, ++MainActivity.numStartAlertTackleBox,
                    receiveMessageFromReceiverBeg, PendingIntent.FLAG_IMMUTABLE);

            // getting the alarm clock to wake it up
            AlarmManager tackleBoxStartAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            // set the alarm
            tackleBoxStartAlarmManager.set(AlarmManager.RTC_WAKEUP, trigger, senderBeginTackleBox);


            return true;


        }

        /***
         ** 8. - need to add the alert me menu end date
         */
        if (tackleBodMenuItemToPick.getItemId() == R.id.notifyTackleBoxDetailsEndDetails) {

            // end date for fishing lessons notification
            String endFishingLessonDateFromBefore = changeEndDateForTackleBox.getText().toString();

            String myTackleBoxDetailsEndFormat = "MM/dd/yy";

            SimpleDateFormat sidf = new SimpleDateFormat(myTackleBoxDetailsEndFormat, Locale.US);

            Date tackleBoxEndDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                tackleBoxEndDateForHere = sidf.parse(endFishingLessonDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long triggerEnd = tackleBoxEndDateForHere.getTime();
            // making a new intent
            Intent receiveMessageFromReceiverEnd = new Intent(TackleBoxDetailPage.this, MyReceiver.class);
            receiveMessageFromReceiverEnd.putExtra("key", tackleBoxEndDateForHere + "should trigger!");

            // sender
            PendingIntent senderEndTackleBox = PendingIntent.getBroadcast(TackleBoxDetailPage.this, ++MainActivity.numEndAlertTackleBox,
                    receiveMessageFromReceiverEnd, PendingIntent.FLAG_IMMUTABLE);

            // alarm clock to wake it up
            AlarmManager tackleBoxDetailEndAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            // setting the alarm with the wakeupcall
            tackleBoxDetailEndAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerEnd, senderEndTackleBox);

        }

        // delete button
        if (tackleBodMenuItemToPick.getItemId() == R.id.deleteTackleBox) {
            // deleting a tacklebox


            // using a for each loop
            for (TackleBox crs : repository.getmAllTackleBoxes()) {
                if (crs.getTackleBoxID() == tackleBoxID) crntCrs = crs;
            }

            // need to check on if there are a number of bait attached
            numberOfBaitAttached = 0;

            // need to do another for loop need to know which tackleboxes  are with each piece of bait
            for (Bait bait : repository.getmAllBait()) {
                // if tacklebox attached = to rod/reelId then increment
                if (bait.getTackleBoxID() == tackleBoxID) ++numberOfBaitAttached;
            }
            if (numberOfBaitAttached == 0) {
                // if there isn't any bait attached then you can delete
                repository.deleteTackleBox(crntCrs);

                // adding toast message to show which tacklebox got deleted
                Toast.makeText(TackleBoxDetailPage.this, crntCrs.getTackleBoxName() +
                        " was deleted from the list.", Toast.LENGTH_LONG).show();
                // going back to cours list
                Intent goBackToTackleListScreen = new Intent(TackleBoxDetailPage.this, TackleBoxes.class);
                startActivity(goBackToTackleListScreen);

            }

            // creating another toast message to say  that you can't delete a tacklebox with a
            // attached to the tacklebox, delete the bait first
            else {
                Toast.makeText(TackleBoxDetailPage.this,
                        "You can't delete the tackle box. Please delete the associated bait",
                        Toast.LENGTH_LONG).show();

            }

        }
        if (tackleBodMenuItemToPick.getItemId() == R.id.homePageFromTackleBoxDetail) {
            Intent goBackToHomePage = new Intent(TackleBoxDetailPage.this, MainActivity.class);

            Toast.makeText(TackleBoxDetailPage.this,
                    // test to make sure it go to the page
                    "Going Back To the Home Page",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToHomePage);

            return true;
        }

        return true;
    }







/****
 *** end of the line
 *** don't continue
 **/
/*(****)---(****)---     REQUIREMENTS    (****)--- (****)--- (****)--- (****)---
    - can't deleted associated bait with it
    - need to be delete, add, and update

    (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)---  */
}
