package com.example.myschoolapp.Database;

import android.app.Application;

import com.example.myschoolapp.DAO.BaitDAO;
import com.example.myschoolapp.DAO.TackleBoxDAO;
import com.example.myschoolapp.DAO.RodAndReelDAO;
import com.example.myschoolapp.entities.Bait;
import com.example.myschoolapp.entities.TackleBox;
import com.example.myschoolapp.entities.RodAndReel;


import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {



    private TackleBoxDAO mTackleBoxDAO;
    private RodAndReelDAO mRodAndReelDAO;
    private BaitDAO mBaitDAO;


    private List<RodAndReel> mAllRodAndReels;
    private List <TackleBox> mAllTackleBoxes;
    private List<Bait> mAllBait;


    private static int NUMBER_OF_THREADS =4;
    static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public Repository(List<RodAndReel> mAllRodAndReels, List<TackleBox> mAllTackleBoxes, List<Bait> mAllBait) {
        this.mAllRodAndReels = mAllRodAndReels;
        this.mAllTackleBoxes = mAllTackleBoxes;
        this.mAllBait = mAllBait;

    }

  public Repository(Application application){
        MySchoolAppDatabaseBuilder databaseBuilder = MySchoolAppDatabaseBuilder.getDatabase(application);

        mRodAndReelDAO = databaseBuilder.rodAndReelDAO();
        mTackleBoxDAO = databaseBuilder.tackleBoxDAO();
        mBaitDAO = databaseBuilder.baitDAO();

  }


    // get all Methods




    public List<RodAndReel> getmAllRodsAndReels(){
        databaseExecutor.execute(()->{
            mAllRodAndReels = mRodAndReelDAO.getAllRodsAndReels();
        });

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return mAllRodAndReels;
    }

    public List<TackleBox> getmAllTackleBoxes(){
        databaseExecutor.execute(()->{
            mAllTackleBoxes = mTackleBoxDAO.getAllTackleBoxes();
        });
        try{
            Thread.sleep(100);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
        return mAllTackleBoxes;
    }





    public List<Bait> getmAllBait(){
        databaseExecutor.execute(()->{
            mAllBait = mBaitDAO.getAllBait();
        });
        try {
            Thread.sleep(100);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        return mAllBait;
    }

    //insert methods




    // rodAndReel
    public void insertRodAndReel(RodAndReel rodAndReel){
        databaseExecutor.execute(()-> mRodAndReelDAO.insertRodAndReel(rodAndReel));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    // tackleBox
    public void insertTackleBox(TackleBox tackleBox){
        databaseExecutor.execute(()-> mTackleBoxDAO.insertTackleBox(tackleBox));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    // bait
    public void insertBait(Bait bait){
        databaseExecutor.execute(()-> mBaitDAO.insertBait(bait));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    //delete methods
    //tackleBox
   public void deleteTackleBox(TackleBox tackleBox){
        databaseExecutor.execute(()-> mTackleBoxDAO.deleteTackleBox(tackleBox));
        try{
            Thread.sleep(100);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
   }

    //bait
    public void deleteBait(Bait bait){
        databaseExecutor.execute(()-> mBaitDAO.deleteBait(bait));
        try{
            Thread.sleep(100);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    //rodAndReel
    public void deleteRodAndReel(RodAndReel rodAndReel){
        databaseExecutor.execute(()-> mRodAndReelDAO.deleteRodAndReel(rodAndReel));
        try{
            Thread.sleep(100);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }


    // update methods



    // bait
    public void updateBait(Bait bait){
        databaseExecutor.execute(()-> mBaitDAO.updateBait(bait));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    // rodAndReel
    public void updateRodAndReel(RodAndReel rodAndReel){
        databaseExecutor.execute(()-> mRodAndReelDAO.updateRodAndReel(rodAndReel));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    //tackleBox
    //
    public void updateTackleBox(TackleBox tackleBox){
        databaseExecutor.execute(()-> mTackleBoxDAO.updateTackleBox(tackleBox));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }


    public List<TackleBox> getRodAndTackle(int rodAndReelID) {
        databaseExecutor.execute(() ->{
            mAllTackleBoxes = mTackleBoxDAO.getRodAndTackle(rodAndReelID);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return mAllTackleBoxes;
    }

    /***
     ** 1. - getting the assessment id
     */

    public Bait getBaitById(Integer id){
        if(mAllBait == null){
            getmAllBait();
        }
        if(mAllBait != null){
            for(Bait bait : mAllBait){
                if(id == bait.getBaitID()){
                    return bait;
                }
            }
        }
        return null;
    }

    /***
     ** 2. - getting the id from a string for bait
     */
    public Bait getBaitFromString(String bait){
        if(mAllBait == null){
            getmAllBait();
        }
        for(Bait bait1 : mAllBait){
            if(bait1.toString().equals(bait)){
                return bait1;
            }
        }
        return null;
    }

    /***
     ** 3. getting the biggest number of bait
     */
    public Integer getMaxAssessmentId(){
        if(mAllBait == null){
            getmAllBait();
        }
        Bait lastBait = mAllBait.get(mAllBait.size() - 1);
        return lastBait.getBaitID();
    }


}
