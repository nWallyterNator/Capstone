package com.example.myschoolapp.Activity.Report;

public class DValidator {
    /*************
     ************* # Login Screen
     */

    // Test #1 in the Login Screen 01/17/2024 @ 9:00 =
    // Login Screen = checking to see if the login lets me login with an invalid password.

    /***
     ** expected result = it shouldn't allow me to go to the next screen
     */

    /**
     * procedure = ran the app on my personal android pixel 4 and keyed in "username" for password
     *  and user name.
     */


    /**((((((     Success    PASSED        ))))))*/



    // Test # 2 in the login Screen 01/17/2024 @ 9:15 =
    // Login Screen = making sure that I can login in with user name fish and password fish

    /***
     ** expected result = it should go to the home page
     */

    /**
     * procedure = ran the app on my personal android pixel 4 and keyed in "fish" for password
     *  and user name.
     */

    /**((((((     Success    PASSED        ))))))*/







    /*************
     ************* # Search Bar Screen
     */
    // Test # 3 in the Search Bar Screen 01/17/2024 @ 9:45 =
    // Low Stock Screen =  making sure that it doesn't duplicate the items on the list

    /***
     ** expected result = it should have 9 items after you hit back
     */

    /**
     * procedure =  hit low stock button and counted 9 items, hit the back arrow from phone

     */

    /** :(:(:(:(:(:( FAILURE :(:(:(:(:(:(:(:(*/


    // Test # 4 in the Search Bar Screen 01/17/2024 @ 10:15 =
    // Low Stock Screen =  making sure that it doesn't duplicate the items on the list
    /***
     ** expected result = it should have 9 items after you hit back
     */

    /**
     * procedure =  added a cancel button in the menu to see if it had something to do with the back arrow

     */

    /** :(:(:(:(:(:( FAILURE :(:(:(:(:(:(:(:(*/









    /*************
     ************* # Recycle View / List Screen
     */
    // Test # 5 in the Rods and Reels Page 01/17/2024 @ 10:35 =
    // Rods and Reels Screen = need to validate that the list is updating from when I add a new rod
    // and reel combo

    /***
     ** expected result = it should save when I am adding a new Rod and Reel page
     */

    /**
     * procedure =  adding a pretend Rod and Reel deal to validate that it shows up in the
     ** list of on the Rod and Reels Page, it should be added to the list, hit save button
     */


    /**((((((     Success    PASSED        ))))))*/








    /*************
     ************* # Text Box
     */
    // Test # 6 in the Rods and Reel Detail Page 01/17/2024 @ 11:17 =
    // Rod and Reel Detail  Screen = need to validate that there will be an error that pops up due to a
    // null insertion

    /***
     ** expected result = it should stop the user from continuing on.
     */

    /**
     * procedure =  left rod name blank, did the order date and sold date
     **
     */


    /** :(:(:(:(:(:( FAILURE :(:(:(:(:(:(:(:(*/



    // Test # 7 in the Rods and Reel Detail Page 01/17/2024 @ 11:35 =
    // Rod and Reel Detail  Screen = need to validate that there will be an error that pops up due to a
    // null insertion

    /***
     ** expected result = it should stop the user from continuing on and display an error
     */

    /**
     * procedure =  adding an if statement to catch anything that equals null
     * trying the same test by just adding the 2 dates but not the name
     **
     */



}
