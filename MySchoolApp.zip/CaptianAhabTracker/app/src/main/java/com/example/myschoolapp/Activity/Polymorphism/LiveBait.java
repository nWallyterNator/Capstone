package com.example.myschoolapp.Activity.Polymorphism;

import androidx.room.Entity;

import com.example.myschoolapp.entities.Bait;

@Entity(tableName = "liveBait")
public class LiveBait extends Bait {

    private int liveBaitReference;

    public int getLiveBaitReference() {
        return liveBaitReference;
    }

    public void setLiveBaitReference(int liveBaitReference) {
        this.liveBaitReference = liveBaitReference;
    }

    public LiveBait(int baitID, String baitName, String beginBaitDay, String endBaitDay, String typeOfBait, int tackleBoxID, int liveBaitReference) {
        super(baitID, baitName, beginBaitDay, endBaitDay, typeOfBait, tackleBoxID);
        this.liveBaitReference = liveBaitReference;
    }
}
