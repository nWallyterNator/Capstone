package com.example.myschoolapp.Activity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Bait;
import com.example.myschoolapp.entities.TackleBox;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;


/****
 *** @author Nicholas Walters
 **/
public class BaitDetailPage extends AppCompatActivity {
    /***
     ** 9. - spinner for the tackle boxes
     ** - list of tackleboxes
     */
    // spinner
    Spinner tackleBoxAndBaitSpinner;

    // list of TackleBoxes
    List<TackleBox> cours;


    /*** 4. - buttons, save and cancel
     **
     */
    // 2 visible buttons, save bait and cancel button
    Button saveBaitBtn, cancelBtn;

    /*** 1. - need bait name
     **  -  need to set the bait name
     */
    // Edit name
    EditText changeBaitName;
    // set bait name string
    String baitName;

    /***
     **  2. - need start and end dates
     **  -  dialog date pickers for begin and end dates
     **  -  strings needed for dates
     */
    //text view needed for begining date and ending date
    TextView changeBegDateForBait, changeEndDateForBait;

    // dialog begin and end dates
    DatePickerDialog.OnDateSetListener beginBaitDate, endBaitDate;

    //Calenders start and end for fishing lessons
    final Calendar baitStartCalendar = Calendar.getInstance();
    final Calendar baitEndCalendar = Calendar.getInstance();

    // strings for start and begin date
    String startingBaitDate, endingBaitDate;


    /***
     **  3. - need bait type
     **  - using a type spinner
     **  - the setter will be a string
     **  - need to make a position
     */

    // string to get
    String typeOfBait;
    Spinner baitSpinnerType;


    /***
     ** 5. - bait id, tacklebox id
     */
    // need a tackleBoxId and baitid
    int baitID;
    int tackleBoxID;

    /***
     ** 6. - need bait for the save button
     */
    Bait test;

    /***
     ** 7. - repository needed
     */
    Repository repository;

    /**
     * * 8. - need  current bait to delete
     */
    Bait crntTest;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bait_detail_page);

        repository = new Repository(getApplication());

        /***
         ** 9 . calling the spinner by the id
         ** - calling a method to get the spinner for the tackleboxkes that go with
         ** - need to make it clickable
         */
        tackleBoxAndBaitSpinner = findViewById(R.id.tackleAndBaitSpinner);
        // calling spinner
        createBaitTackleSpinner();
        // making it clickable
        tackleBoxAndBaitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // getting a new tackleBox
                // getting i which is the position
                TackleBox chosenTackleBox = cours.get(i);
                tackleBoxID = chosenTackleBox.getTackleBoxID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        /***
         ** 1. - need ids and to get the bait name, setting
         */
        // id for changeBait Name
        changeBaitName = findViewById(R.id.changeBaitDetailNameEv);
        // getting bait name from adapter
        baitName = getIntent().getStringExtra("assessmentName");

        // setting name
        changeBaitName.setText(baitName);


        /***
         ** 2. - date need to set a simple string
         */
        // adding format for date and adding a string
        String myFormatForCalendar = "MM/dd/yy";
        // adding SimpleDateFormat
        SimpleDateFormat sdf = new SimpleDateFormat(myFormatForCalendar, Locale.US);

        /***
         ** 3. - need ids for spinner
         ** - getter for spinner
         ** - getting the data for the spinner
         */
        baitSpinnerType = findViewById(R.id.baitDetailSpinnerType);

        //getter for spinnner
        typeOfBait = getIntent().getStringExtra("testType");

        // info for spinner
        ArrayAdapter<CharSequence> testAdapter = ArrayAdapter.createFromResource(this,
                R.array.bait_type, android.R.layout.simple_spinner_dropdown_item);
        testAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        baitSpinnerType.setAdapter(testAdapter);

        // to make sure it will add it
        if (baitID != -1) {
            int testStatusPosition = testAdapter.getPosition(typeOfBait);
            baitSpinnerType.setSelection(testStatusPosition);

        }


        /***
         ** 5. - getting bait id from adapter and tackleBox id
         */
        baitID = getIntent().getIntExtra("assessmentID", -1);
        // tackleBox id
        tackleBoxID = getIntent().getIntExtra("courseID", -1);


        /***
         ** 2. - getting a new calendar and set method
         ** - need ids
         ** - get the starting and end date info from adapters
         ** - setting the date
         ** - need to make it a button to make it clickable
         ** - new dialogs needed
         */
        // ids
        //ids
        changeBegDateForBait = findViewById(R.id.changBaitStartDateEv);
        changeEndDateForBait = findViewById(R.id.changeBaitDetailsEndDate);

        //getting the info from the strings from the adapter
        startingBaitDate = getIntent().getStringExtra("beginDate");
        endingBaitDate = getIntent().getStringExtra("endDate");

        //setting
        // setting info using an if statement if its at -1
        if (baitID == -1) {
            changeBegDateForBait.setText(sdf.format(new Date()));
            changeEndDateForBait.setText(sdf.format(new Date()));
            // if it is found
            // else statement
        } else {
            changeEndDateForBait.setText(endingBaitDate);
            changeBegDateForBait.setText(startingBaitDate);
        }

        // making it a button to be clickable
        //start date
        changeBegDateForBait.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeBegDateForBait.getText().toString();

                if (info.equals("")) info = "12/01/23";
                // try and catch statement
                try {
                    // calling the begin calendar
                    baitStartCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog date picker
                new DatePickerDialog(BaitDetailPage.this, beginBaitDate,
                        baitStartCalendar.get(Calendar.YEAR),
                        //month for calender
                        baitStartCalendar.get(Calendar.MONTH),
                        // day of the month
                        baitStartCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // end date button
        changeEndDateForBait.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeEndDateForBait.getText().toString();

                if (info.equals("")) info = "12/01/23";
                //try and catch statement
                try {
                    //calling the end calender
                    baitEndCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog datepicker
                new DatePickerDialog(BaitDetailPage.this, endBaitDate, baitEndCalendar
                        .get(Calendar.YEAR),
                        //month
                        baitEndCalendar.get(Calendar.MONTH),
                        // day
                        baitEndCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        // new end date new date picker dialog
        endBaitDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year
                baitEndCalendar.set(Calendar.YEAR, year);
                // month
                baitEndCalendar.set(Calendar.MONTH, month);
                // day
                baitEndCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update ending label
                updateEndingBaitLabel();

            }


        };
        // new start date picker dialog
        beginBaitDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year from the begin calendar
                baitStartCalendar.set(Calendar.YEAR, year);
                // month
                baitStartCalendar.set(Calendar.MONTH, month);
                // day
                baitStartCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update start label method
                updateStartingBaitLabel();

            }
        };

        /***
         ** 4. - buttons = save and cancel button
         */
        saveBaitBtn = findViewById(R.id.saveBaitDetailBTT);
        //  the save button should save info and go back to the previous page
        saveBaitBtn.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {


                // need to make sure that bait id is found
                if (baitID == -1) {
                    // if bait isn't found create new bait
                    test = new Bait(0, changeBaitName.getText().toString(),
                            changeBegDateForBait.getText().toString(),
                            changeEndDateForBait.getText().toString(), baitSpinnerType.getSelectedItem().toString(),
                            tackleBoxID);
                    // need to insert the new bait into the repository
                    repository.insertBait(test);

                    // going back to the screen to refresh so we can see if it worked vs going back and forth
                    Intent goBackWithSavedBait = new Intent(BaitDetailPage.this,
                            Baits.class);
                    startActivity(goBackWithSavedBait);
                }
                // else if it is found then we will update the bait
                else {
                    test = new Bait(baitID, changeBaitName.getText().toString(),
                            changeBegDateForBait.getText().toString(),
                            changeEndDateForBait.getText().toString(), baitSpinnerType.getSelectedItem().toString(), tackleBoxID);
                    // update bait in repository
                    repository.updateBait(test);

                    // going back to the screen to refresh so we can see if it worked vs going back and forth
                    Intent goBackWithSavedBait = new Intent(BaitDetailPage.this,
                            Baits.class);
                    startActivity(goBackWithSavedBait);
                }


                //

            }
        });


        //Cancel Btn
        cancelBtn = findViewById(R.id.cancelRodReelDetailBTT);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBackToBaits = new Intent(BaitDetailPage.this, Baits.class);

                Toast.makeText(BaitDetailPage.this,
                        // test to make sure it go to the page
                        "Canceling Request",
                        Toast.LENGTH_SHORT).show();
                startActivity(goBackToBaits);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_bait_detail_page, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {


        if (menuItem.getItemId() == R.id.deleteBaitDetailsPageMenuItem) {
            // deleting bait

            // using a for each loop
            for (Bait tst : repository.getmAllBait()) {
                if (tst.getBaitID() == baitID) {
                    Bait crntTest = tst;
                    repository.deleteBait(crntTest);
                }

            }
            // adding toast message to show which bait got deleted
            Toast.makeText(BaitDetailPage.this, crntTest.getBaitName() +
                    " was deleted from the list.", Toast.LENGTH_LONG).show();
            // going back to baits list
            Intent goBackToBaitsScreen = new Intent(BaitDetailPage.this, RodAndReels.class);
            startActivity(goBackToBaitsScreen);

            return true;
        }

        /***
         ** 4. - need to add the alert me menu start date
         */
        if (menuItem.getItemId() == R.id.fishingLessonStartDate) {

            // begin date for fishing lesson
            String startBaitDateFromBefore = changeBegDateForBait.getText().toString();

            String myBaitBeginFormat = "MM/dd/yy";

            SimpleDateFormat sdf = new SimpleDateFormat(myBaitBeginFormat, Locale.US);

            Date BaitBeginDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                BaitBeginDateForHere = sdf.parse(startBaitDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long trigger = BaitBeginDateForHere.getTime();
            // need to build the receiver
            Intent receiveMessageFromReceiverBeg = new Intent(BaitDetailPage.this, MyReceiver.class);
            // message to add on what I want them to see
            receiveMessageFromReceiverBeg.putExtra("key", BaitBeginDateForHere + "should trigger");

            // sender
            PendingIntent senderBeginBait = PendingIntent.getBroadcast(BaitDetailPage.this, ++MainActivity.numStartAlertTest,
                    receiveMessageFromReceiverBeg, PendingIntent.FLAG_IMMUTABLE);

            // getting the alarm clock to wake it up
            AlarmManager baitStartAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            // set the alarm
            baitStartAlarmManager.set(AlarmManager.RTC_WAKEUP, trigger, senderBeginBait);


            return true;


        }

        /***
         ** 8. - need to add the alert me menu end date
         */
        if (menuItem.getItemId() == R.id.fishingLessonEndDate) {

            // end date for tackleBox notification
            String endBaitDateFromBefore = changeEndDateForBait.getText().toString();

            String myBaitEndFormat = "MM/dd/yy";

            SimpleDateFormat sidf = new SimpleDateFormat(myBaitEndFormat, Locale.US);

            Date baitEndDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                baitEndDateForHere = sidf.parse(endBaitDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long triggerEnd = baitEndDateForHere.getTime();
            // making a new intent
            Intent receiveMessageFromReceiverEnd = new Intent(BaitDetailPage.this, MyReceiver.class);
            receiveMessageFromReceiverEnd.putExtra("key", baitEndDateForHere + "should trigger!");

            // sender
            PendingIntent senderEndBait = PendingIntent.getBroadcast(BaitDetailPage.this, ++MainActivity.numEndAlertTest,
                    receiveMessageFromReceiverEnd, PendingIntent.FLAG_IMMUTABLE);

            // alarm clock to wake it up
            AlarmManager baitEndAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            // setting the alarm with the wakeupcall
            baitEndAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerEnd, senderEndBait);

        }




        if(menuItem.getItemId() == R.id.homePageFromBaitDetail) {
            Intent goBackToHomePage = new Intent(BaitDetailPage.this, MainActivity.class);

            Toast.makeText(BaitDetailPage.this,
                    // test to make sure it go to the page
                    "Going Back To the Home Page",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToHomePage);

            return true;
        }

        return true;
    }








 /*@@$@$$$$@@@@$@$$$$@@ @@$@$$$$@@      METHODS    @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@

   @@$@$$$$@@@@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@   */
public  void createBaitTackleSpinner(){
    // calling and updating the repository
    Repository repository = new Repository(getApplication());

    // getting tackleboxes
    cours = repository.getmAllTackleBoxes();

    // creating a list of all tackleboxes to hold it
    // I want the tackleBox names to drop it down
    List<String> courseNames = new ArrayList<>();

    // for loop to go through all of the tackleboxes to find the one that matches
    for (TackleBox tackleBox : cours){
        courseNames.add(tackleBox.getTackleBoxName());
    }

    // adding the new adapter
    ArrayAdapter<String> courseSpinnerAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, courseNames);
    tackleBoxAndBaitSpinner.setAdapter(courseSpinnerAdapter);
}


    private void updateEndingBaitLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeEndDateForBait.setText(sdf.format(baitEndCalendar.getTime()));


    }

    private void updateStartingBaitLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeBegDateForBait.setText(sdf.format(baitStartCalendar.getTime()));
    }


    /****
     *** end of the line
     *** don't continue
     **/
    /*%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%    REQUIREMENTS     %%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%
    - need to add as many bait as I want
    - need a performance and objective option for each tackleBox
    - add the titles for each bait
    - add, update delete
    - beginning and end dates


    %%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%
  */
}